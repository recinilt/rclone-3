"""
Dual Pane RClone File Manager v1.4 - Paket Başlatma Dosyası
"""

__version__ = "1.4"
__author__ = "RClone Manager"
__description__ = "İki panelli dosya yöneticisi ile görsel dosya transferi"

from .dual_pane_manager import DualPaneRCloneManager

__all__ = ['DualPaneRCloneManager']