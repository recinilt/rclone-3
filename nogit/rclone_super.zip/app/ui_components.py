"""
Kullanıcı arayüzü bileşenleri
"""

import tkinter as tk
from tkinter import ttk, scrolledtext
import webbrowser


class UIComponents:
    """UI bileşenlerini oluşturan sınıf"""
    
    def __init__(self, parent):
        self.parent = parent
    
    def setup_menu(self, callbacks):
        """Menü çubuğunu oluştur"""
        menubar = tk.Menu(self.parent)
        self.parent.config(menu=menubar)
        
        # Dosya menüsü
        file_menu = tk.Menu(menubar, tearoff=0)
        menubar.add_cascade(label="Dosya", menu=file_menu)
        file_menu.add_command(label="Yeni Bağlantı...", command=callbacks['new_connection'])
        file_menu.add_separator()
        file_menu.add_command(label="Sol Paneli Yenile", command=callbacks['refresh_left'])
        file_menu.add_command(label="Sağ Paneli Yenile", command=callbacks['refresh_right'])
        file_menu.add_separator()
        file_menu.add_command(label="Çıkış", command=callbacks['quit'])
        
        # İşlemler menüsü
        operations_menu = tk.Menu(menubar, tearoff=0)
        menubar.add_cascade(label="İşlemler", menu=operations_menu)
        operations_menu.add_command(label="Soldan Sağa Kopyala", command=callbacks['copy_left_to_right'])
        operations_menu.add_command(label="Sağdan Sola Kopyala", command=callbacks['copy_right_to_left'])
        operations_menu.add_separator()
        operations_menu.add_command(label="İki Yönlü Senkronizasyon", command=callbacks['bidirectional_sync'])
        operations_menu.add_command(label="Sol → Sağ Senkronizasyon", command=callbacks['sync_left_to_right'])
        operations_menu.add_command(label="Sağ → Sol Senkronizasyon", command=callbacks['sync_right_to_left'])
        operations_menu.add_separator()
        operations_menu.add_command(label="Seçili Öğeyi Sil", command=callbacks['delete_selected'])
        operations_menu.add_separator()
        operations_menu.add_command(label="Son İşlem Raporu", command=callbacks['show_last_report'])
        
        # Araçlar menüsü
        tools_menu = tk.Menu(menubar, tearoff=0)
        menubar.add_cascade(label="Araçlar", menu=tools_menu)
        tools_menu.add_command(label="RClone Yapılandırması", command=callbacks['open_rclone_config'])
        tools_menu.add_command(label="Bağlantıları Listele", command=callbacks['list_remotes'])
        tools_menu.add_separator()
        tools_menu.add_command(label="Seçenekler...", command=callbacks['show_preferences'])
        
        # Yardım menüsü
        help_menu = tk.Menu(menubar, tearoff=0)
        menubar.add_cascade(label="Yardım", menu=help_menu)
        help_menu.add_command(label="Kullanım Kılavuzu", command=callbacks['show_help'])
        help_menu.add_command(label="RClone Dokümantasyonu", 
                             command=lambda: webbrowser.open("https://rclone.org/docs/"))
        help_menu.add_separator()
        help_menu.add_command(label="Hakkında", command=callbacks['show_about'])
    
    def setup_toolbar(self, callbacks, control_vars):
        """Araç çubuğunu oluştur"""
        # Ana toolbar frame
        toolbar_main = ttk.Frame(self.parent)
        toolbar_main.pack(side=tk.TOP, fill=tk.X, padx=5, pady=2)
        
        # İlk satır - Ana butonlar
        toolbar_row1 = ttk.Frame(toolbar_main)
        toolbar_row1.pack(side=tk.TOP, fill=tk.X, pady=(0, 2))
        
        # Bağlantı butonları
        ttk.Button(toolbar_row1, text="🔗 Yeni Bağlantı", 
                  command=callbacks['new_connection'], width=15).pack(side=tk.LEFT, padx=2)
        
        ttk.Separator(toolbar_row1, orient='vertical').pack(side=tk.LEFT, fill=tk.Y, padx=5)
        
        # Transfer butonları
        ttk.Button(toolbar_row1, text="➡️ Sol → Sağ", 
                  command=callbacks['copy_left_to_right'], width=12).pack(side=tk.LEFT, padx=2)
        ttk.Button(toolbar_row1, text="⬅️ Sağ → Sol", 
                  command=callbacks['copy_right_to_left'], width=12).pack(side=tk.LEFT, padx=2)
        
        ttk.Separator(toolbar_row1, orient='vertical').pack(side=tk.LEFT, fill=tk.Y, padx=5)
        
        # Senkronizasyon butonları
        ttk.Button(toolbar_row1, text="🔄 İki Yönlü Sync", 
                  command=callbacks['bidirectional_sync'], width=15).pack(side=tk.LEFT, padx=2)
        ttk.Button(toolbar_row1, text="🗑️ Sil", 
                  command=callbacks['delete_selected'], width=8).pack(side=tk.LEFT, padx=2)
        
        ttk.Separator(toolbar_row1, orient='vertical').pack(side=tk.LEFT, fill=tk.Y, padx=5)
        
        # Yenileme butonları
        ttk.Button(toolbar_row1, text="🔄 Sol Panel", 
                  command=callbacks['refresh_left'], width=10).pack(side=tk.LEFT, padx=2)
        ttk.Button(toolbar_row1, text="🔄 Sağ Panel", 
                  command=callbacks['refresh_right'], width=10).pack(side=tk.LEFT, padx=2)
        
        # Log ve Rapor butonları
        ttk.Button(toolbar_row1, text="📋 Log", 
                  command=callbacks['toggle_log'], width=8).pack(side=tk.LEFT, padx=2)
        ttk.Button(toolbar_row1, text="📊 Rapor", 
                  command=callbacks['show_last_report'], width=8).pack(side=tk.LEFT, padx=2)
        
        # Durdur butonu (sağda)
        stop_btn = ttk.Button(toolbar_row1, text="⏹️ Durdur", 
                              command=callbacks['stop_operation'], state='disabled')
        stop_btn.pack(side=tk.RIGHT, padx=2)
        
        # İkinci satır - Seçenekler
        toolbar_row2 = ttk.Frame(toolbar_main)
        toolbar_row2.pack(side=tk.TOP, fill=tk.X)
        
        # Seçenekler frame'i
        options_frame = ttk.LabelFrame(toolbar_row2, text="⚙️ Seçenekler")
        options_frame.pack(side=tk.LEFT, padx=2, pady=2, fill=tk.Y)
        
        # Checkbox'lar için iç frame
        checkboxes_frame = ttk.Frame(options_frame)
        checkboxes_frame.pack(padx=5, pady=2)
        
        # Test modu checkbox
        ttk.Checkbutton(checkboxes_frame, text="🧪 Test Modu", 
                       variable=control_vars['test_mode'],
                       command=callbacks['on_test_mode_change']).pack(side=tk.LEFT, padx=5)
        
        # Mevcut dosyaları atla checkbox
        ttk.Checkbutton(checkboxes_frame, text="⏭️ Mevcut Dosyaları Atla", 
                       variable=control_vars['ignore_existing'],
                       command=callbacks['on_ignore_existing_change']).pack(side=tk.LEFT, padx=5)
        
        # Hata olduğunda devam et checkbox
        ttk.Checkbutton(checkboxes_frame, text="🔄 Hata Olduğunda Devam Et", 
                       variable=control_vars['ignore_errors'],
                       command=callbacks['on_ignore_errors_change']).pack(side=tk.LEFT, padx=5)
        
        return stop_btn
    
    def create_file_panel(self, parent, title, remote_var, path_var, callbacks):
        """Dosya paneli oluştur"""
        frame = ttk.Frame(parent)
        
        # Panel başlığı
        header = ttk.Frame(frame)
        header.pack(fill=tk.X, pady=(0, 5))
        
        ttk.Label(header, text=title, 
                 font=('Arial', 12, 'bold')).pack(side=tk.LEFT)
        
        # Bağlantı seçimi
        combo = ttk.Combobox(header, textvariable=remote_var,
                            width=25, state="readonly")
        combo.pack(side=tk.RIGHT, padx=5)
        
        # Yol çubuğu
        path_frame = ttk.Frame(frame)
        path_frame.pack(fill=tk.X, pady=(0, 5))
        
        ttk.Label(path_frame, text="📁").pack(side=tk.LEFT)
        entry = ttk.Entry(path_frame, textvariable=path_var)
        entry.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=5)
        
        refresh_btn = ttk.Button(path_frame, text="🔄", width=3)
        refresh_btn.pack(side=tk.RIGHT)
        
        # Dosya listesi
        columns = ('size', 'modified')
        tree = ttk.Treeview(frame, columns=columns, height=15)
        
        # Kolon başlıkları
        tree.heading('#0', text='İsim')
        tree.heading('size', text='Boyut')
        tree.heading('modified', text='Değiştirilme')
        
        # Kolon genişlikleri
        tree.column('#0', width=300)
        tree.column('size', width=100)
        tree.column('modified', width=150)
        
        # Scrollbar
        scrollbar = ttk.Scrollbar(frame, orient='vertical', command=tree.yview)
        tree.configure(yscrollcommand=scrollbar.set)
        
        # Pack
        tree.pack(side=tk.LEFT, fill='both', expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        return frame, combo, entry, refresh_btn, tree
    
    def setup_status_bar(self, parent):
        """Durum çubuğunu oluştur"""
        status_frame = ttk.Frame(parent)
        status_frame.pack(side=tk.BOTTOM, fill=tk.X, padx=5, pady=2)
        
        # Progress bar
        progress = ttk.Progressbar(status_frame, mode='indeterminate')
        progress.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(0, 10))
        
        # Durum metni
        status_label = ttk.Label(status_frame, text="Hazır")
        status_label.pack(side=tk.RIGHT)
        
        return progress, status_label
    
    def setup_log_panel(self, parent):
        """Log paneli oluştur"""
        log_frame = ttk.LabelFrame(parent, text="📝 İşlem Günlüğü")
        log_text = scrolledtext.ScrolledText(log_frame, height=8)
        log_text.pack(fill='both', expand=True, padx=5, pady=5)
        
        return log_frame, log_text