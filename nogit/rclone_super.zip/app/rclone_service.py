"""
RClone işlemleri ve dosya yönetimi - Bundle desteği ile
"""

import subprocess
import sys
import os
from pathlib import Path
from typing import List
from .models import FileItem


def get_rclone_path():
    """RClone executable'ının yolunu bul"""
    if getattr(sys, 'frozen', False):
        # PyInstaller bundle içindeyiz
        if hasattr(sys, '_MEIPASS'):
            # Geçici klasörde
            return os.path.join(sys._MEIPASS, 'rclone.exe')
        else:
            # Exe ile aynı klasörde
            return os.path.join(os.path.dirname(sys.executable), 'rclone.exe')
    else:
        # Normal Python ortamında
        # Önce yerel rclone klasöründe ara
        local_rclone = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'rclone', 'rclone.exe')
        if os.path.exists(local_rclone):
            return local_rclone
        # Sonra PATH'te ara
        return 'rclone'


class RCloneManager:
    """RClone işlemlerini yöneten sınıf"""
    
    def __init__(self):
        self.active_processes = set()
        self.rclone_path = get_rclone_path()
    
    def check_rclone(self) -> tuple[bool, str]:
        """RClone kurulu mu kontrol et"""
        try:
            result = subprocess.run([self.rclone_path, 'version'], capture_output=True, text=True, 
                                  timeout=10, encoding='utf-8', errors='ignore')
            if result.returncode == 0:
                version_line = result.stdout.split('\n')[0]
                bundle_info = " (Bundle)" if getattr(sys, 'frozen', False) else ""
                return True, f"{version_line}{bundle_info}"
            else:
                return False, "rclone bulunamadı"
        except FileNotFoundError:
            return False, f"RClone bulunamadı: {self.rclone_path}"
        except Exception as e:
            return False, str(e)
    
    def load_remotes(self) -> List[str]:
        """Mevcut remote'ları yükle"""
        try:
            result = subprocess.run([self.rclone_path, 'listremotes'], capture_output=True, text=True,
                                  encoding='utf-8', errors='ignore')
            if result.returncode == 0 and result.stdout.strip():
                remotes = [r.strip() for r in result.stdout.strip().split('\n') if r.strip()]
                return remotes
            else:
                return []
        except Exception:
            return []
    
    def list_files(self, remote: str, path: str) -> List[FileItem]:
        """Dosyaları listele"""
        files = []
        
        # Üst dizin ekle (root değilse)
        if path != "/" and path != "":
            parent_path = str(Path(path).parent)
            if parent_path == ".":
                parent_path = "/"
            files.append(FileItem("..", parent_path, True, "", "", remote))
        
        try:
            # Dizinleri listele
            result = subprocess.run([
                self.rclone_path, 'lsd', f"{remote}{path}", '--max-depth', '1'
            ], capture_output=True, text=True, timeout=120, encoding='utf-8', errors='ignore')
            
            if result.returncode == 0 and result.stdout.strip():
                for line in result.stdout.strip().split('\n'):
                    if line.strip():
                        parts = line.strip().split()
                        if len(parts) >= 5:
                            dir_name = ' '.join(parts[4:])
                            dir_path = str(Path(path) / dir_name).replace('\\', '/')
                            modified = f"{parts[1]} {parts[2]}"
                            files.append(FileItem(dir_name, dir_path, True, "", modified, remote))
            
            # Dosyaları listele
            result = subprocess.run([
                self.rclone_path, 'lsl', f"{remote}{path}", '--max-depth', '1'
            ], capture_output=True, text=True, timeout=120, encoding='utf-8', errors='ignore')
            
            if result.returncode == 0 and result.stdout.strip():
                for line in result.stdout.strip().split('\n'):
                    if line.strip():
                        parts = line.strip().split()
                        if len(parts) >= 5:
                            file_name = ' '.join(parts[4:])
                            file_path = str(Path(path) / file_name).replace('\\', '/')
                            size = parts[0]
                            modified = f"{parts[1]} {parts[2]}"
                            files.append(FileItem(file_name, file_path, False, size, modified, remote))
                            
        except subprocess.TimeoutExpired:
            raise Exception("Dosya listeleme zaman aşımına uğradı (2 dakika)")
        except Exception as e:
            raise Exception(f"Dosya listeleme hatası: {e}")
            
        return files
    
    def format_size(self, size_str: str) -> str:
        """Dosya boyutunu formatla"""
        try:
            size = int(size_str)
            if size < 1024:
                return f"{size} B"
            elif size < 1024 * 1024:
                return f"{size // 1024} KB"
            elif size < 1024 * 1024 * 1024:
                return f"{size // (1024 * 1024)} MB"
            else:
                return f"{size // (1024 * 1024 * 1024)} GB"
        except:
            return size_str
    
    def create_copy_process(self, source_path: str, dest_path: str, 
                          is_dir: bool, is_test: bool, ignore_existing: bool, 
                          ignore_errors: bool):
        """Kopyalama process'i oluştur"""
        if is_dir:
            cmd = [self.rclone_path, 'copy', source_path, dest_path, 
                  '--progress', '--stats', '30s', '--transfers', '2', 
                  '--create-empty-src-dirs', '--verbose']
        else:
            cmd = [self.rclone_path, 'copyfile', source_path, dest_path, 
                  '--progress', '--verbose']
        
        # Seçeneklere göre parametreler ekle
        if ignore_existing:
            cmd.append('--ignore-existing')
        if ignore_errors:
            cmd.append('--ignore-errors')
        if is_test:
            cmd.append('--dry-run')
        
        process = subprocess.Popen(
            cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, 
            text=True, encoding='utf-8', errors='ignore', bufsize=1
        )
        
        self.active_processes.add(process)
        return process
    
    def create_sync_process(self, source_path: str, dest_path: str,
                          is_test: bool, ignore_errors: bool):
        """Senkronizasyon process'i oluştur"""
        cmd = [self.rclone_path, 'sync', source_path, dest_path, 
              '--progress', '--transfers', '2', '--verbose']
        
        if ignore_errors:
            cmd.append('--ignore-errors')
        if is_test:
            cmd.append('--dry-run')
        
        process = subprocess.Popen(
            cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, 
            text=True, encoding='utf-8', errors='ignore', bufsize=1
        )
        
        self.active_processes.add(process)
        return process
    
    def create_delete_process(self, path: str, is_dir: bool):
        """Silme process'i oluştur"""
        if is_dir:
            cmd = [self.rclone_path, 'purge', path]
        else:
            cmd = [self.rclone_path, 'delete', path]
        
        process = subprocess.Popen(
            cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, 
            text=True, encoding='utf-8', errors='ignore', bufsize=1
        )
        
        self.active_processes.add(process)
        return process
    
    def cleanup_process(self, process):
        """Process'i temizle"""
        if process in self.active_processes:
            self.active_processes.remove(process)
    
    def terminate_all_processes(self):
        """Tüm aktif process'leri sonlandır"""
        for process in list(self.active_processes):
            try:
                if process.poll() is None:  # Hala çalışıyorsa
                    process.terminate()
                    # 2 saniye bekle
                    try:
                        process.wait(timeout=2)
                    except subprocess.TimeoutExpired:
                        # Zorla kill et
                        process.kill()
                        process.wait()
            except:
                pass
        self.active_processes.clear()
    
    def show_rclone_install_dialog(self):
        """RClone kurulum mesajı"""
        print("❌ RClone bulunamadı!")
        print(f"Aranan konum: {self.rclone_path}")
        print("\nKurulum:")
        print("Windows: winget install Rclone.Rclone")
        print("macOS: brew install rclone")  
        print("Linux: sudo apt install rclone")
        print("\nProgram kapatılıyor...")
        sys.exit(1)