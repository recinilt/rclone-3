"""
Transfer ve senkronizasyon işlemleri
"""

import threading
import subprocess
from pathlib import Path
from typing import List, Callable
from .models import FileItem, TransferResult


class TransferOperations:
    """Transfer işlemlerini yöneten sınıf"""
    
    def __init__(self, rclone_manager, log_callback: Callable[[str], None]):
        self.rclone_manager = rclone_manager
        self.log = log_callback
        self.running = False
        self.current_process = None
        
    def copy_files(self, files: List[FileItem], source_remote: str, 
                   dest_remote: str, dest_path: str, is_test: bool, 
                   ignore_existing: bool, ignore_errors: bool,
                   completion_callback: Callable = None):
        """Dosyaları kopyala"""
        if self.running:
            return False
            
        self.running = True
        result = TransferResult()
        
        thread = threading.Thread(
            target=self._copy_worker,
            args=(files, source_remote, dest_remote, dest_path, 
                  is_test, ignore_existing, ignore_errors, result, completion_callback),
            daemon=False  # daemon=False yaparak process'in düzgün sonlanmasını sağla
        )
        thread.start()
        return True
    
    def _copy_worker(self, files: List[FileItem], source_remote: str,
                    dest_remote: str, dest_path: str, is_test: bool,
                    ignore_existing: bool, ignore_errors: bool,
                    result: TransferResult, completion_callback: Callable = None):
        """Kopyalama worker thread"""
        try:
            total_files = len(files)
            operation_name = "TEST" if is_test else "KOPYALAMA"
            
            self.log(f"🚀 {operation_name} BAŞLADI")
            self.log(f"📋 {total_files} öğe işlenecek")
            self.log(f"📤 Kaynak: {source_remote}")
            self.log(f"📥 Hedef: {dest_remote}{dest_path}")
            
            # Seçenekleri log'la
            self.log("⚙️ SEÇENEKLER:")
            if is_test:
                self.log("   🧪 Test Modu: AÇIK")
            if ignore_existing:
                self.log("   ⏭️ Mevcut Dosyaları Atla: AÇIK")
            if ignore_errors:
                self.log("   🔄 Hata Olduğunda Devam Et: AÇIK")
            
            self.log("=" * 60)
            
            for i, file_item in enumerate(files, 1):
                if not self.running:
                    self.log("🛑 İşlem kullanıcı tarafından durduruldu")
                    break
                    
                self.log(f"📋 [{i}/{total_files}] İşleniyor: {file_item.name}")
                
                # Kaynak ve hedef yolları oluştur
                source_path = f"{source_remote}{file_item.path}"
                
                try:
                    if file_item.is_dir:
                        # Klasör kopyala
                        dest_folder_path = str(Path(dest_path) / file_item.name).replace('\\', '/')
                        dest_full_path = f"{dest_remote}{dest_folder_path}"
                        self.log(f"📁 Klasör işleniyor: {file_item.name}")
                    else:
                        # Dosya kopyala
                        dest_file_path = str(Path(dest_path) / file_item.name).replace('\\', '/')
                        dest_full_path = f"{dest_remote}{dest_file_path}"
                        self.log(f"📄 Dosya işleniyor: {file_item.name}")
                    
                    # Process oluştur
                    self.current_process = self.rclone_manager.create_copy_process(
                        source_path, dest_full_path, file_item.is_dir,
                        is_test, ignore_existing, ignore_errors
                    )
                    
                    # Canlı çıktı takibi
                    output_lines = []
                    error_lines = []
                    skipped_lines = []
                    
                    while True:
                        if not self.running:
                            self.current_process.terminate()
                            break
                            
                        output = self.current_process.stdout.readline()
                        if output == '' and self.current_process.poll() is not None:
                            break
                        if output:
                            line = output.strip()
                            output_lines.append(line)
                            
                            # Hatalar ve atlanan dosyaları takip et
                            if "ERROR" in line.upper():
                                error_lines.append(line)
                                if len(line) > 100:
                                    line = line[:97] + "..."
                                self.log(f"   ❌ {line}")
                            elif "NOTICE" in line.upper() and ("skipping" in line.lower() or "exists" in line.lower()):
                                skipped_lines.append(line)
                                if len(line) > 100:
                                    line = line[:97] + "..."
                                self.log(f"   ⏭️ {line}")
                            elif line and not line.startswith('[') and "transferred" not in line.lower():
                                # Diğer bilgi mesajları
                                if len(line) > 100:
                                    line = line[:97] + "..."
                                if line.strip():
                                    self.log(f"   📝 {line}")
                    
                    # Process sonucunu kontrol et
                    return_code = self.current_process.poll()
                    
                    # Process'i temizle
                    self.rclone_manager.cleanup_process(self.current_process)
                    self.current_process = None
                    
                    # Sonuçları değerlendir
                    has_errors = len(error_lines) > 0
                    has_skipped = len(skipped_lines) > 0
                    
                    if return_code == 0 or (return_code != 0 and not has_errors):
                        # Başarılı
                        result.success_files.append(file_item.name)
                        
                        if has_skipped:
                            result.skipped_files.extend(skipped_lines)
                            if is_test:
                                self.log(f"✅ Test başarılı (bazı öğeler mevcut): {file_item.name}")
                            else:
                                self.log(f"✅ Kopyalandı (bazı öğeler mevcut): {file_item.name}")
                        else:
                            if is_test:
                                self.log(f"✅ Test başarılı: {file_item.name}")
                            else:
                                self.log(f"✅ Kopyalandı: {file_item.name}")
                    else:
                        # Hata var
                        result.failed_files.append(file_item.name)
                        result.error_details[file_item.name] = error_lines
                        
                        self.log(f"❌ Hata: {file_item.name}")
                        if error_lines:
                            error_summary = error_lines[-1] if len(error_lines) == 1 else f"{len(error_lines)} hata"
                            self.log(f"   💬 {error_summary[:200]}...")
                        
                except subprocess.TimeoutExpired:
                    result.failed_files.append(file_item.name)
                    result.error_details[file_item.name] = ["Timeout (30 dakika)"]
                    self.log(f"⏰ Zaman aşımı (30 dakika): {file_item.name}")
                except Exception as e:
                    result.failed_files.append(file_item.name)
                    result.error_details[file_item.name] = [str(e)]
                    self.log(f"💥 Beklenmeyen hata: {file_item.name} - {e}")
                    
            # İşlem tamamlandı
            self.log("=" * 60)
            
            success_count = len(result.success_files)
            failed_count = len(result.failed_files)
            skipped_count = len(result.skipped_files)
            
            if is_test:
                self.log(f"🧪 TEST TAMAMLANDI:")
                self.log(f"   ✅ Başarılı: {success_count}")
                self.log(f"   ❌ Hatalı: {failed_count}")
                self.log(f"   ⏭️ Atlanan: {skipped_count}")
                self.log("💡 Gerçek kopyalama için Test Modu'nu kapatın")
            else:
                self.log(f"🏁 KOPYALAMA TAMAMLANDI:")
                self.log(f"   ✅ Başarılı: {success_count}")
                self.log(f"   ❌ Hatalı: {failed_count}")
                self.log(f"   ⏭️ Atlanan: {skipped_count}")
                
            if failed_count > 0 or skipped_count > 0:
                self.log("📊 Detaylı rapor için 'Rapor' butonuna tıklayın")
            
            # Callback çağır
            if completion_callback:
                completion_callback(result, is_test)
                
        except Exception as e:
            operation = "test" if is_test else "kopyalama"
            self.log(f"💥 {operation.title()} hatası: {e}")
        finally:
            self.running = False
            self.current_process = None
    
    def sync_directories(self, source_remote: str, source_path: str,
                        dest_remote: str, dest_path: str, operation_name: str,
                        is_test: bool, ignore_errors: bool,
                        completion_callback: Callable = None):
        """Dizinleri senkronize et"""
        if self.running:
            return False
            
        self.running = True
        result = TransferResult()
        
        thread = threading.Thread(
            target=self._sync_worker,
            args=(source_remote, source_path, dest_remote, dest_path,
                  operation_name, is_test, ignore_errors, result, completion_callback),
            daemon=False
        )
        thread.start()
        return True
    
    def _sync_worker(self, source_remote: str, source_path: str,
                    dest_remote: str, dest_path: str, operation_name: str,
                    is_test: bool, ignore_errors: bool, result: TransferResult,
                    completion_callback: Callable = None):
        """Senkronizasyon worker"""
        try:
            operation_type = "TEST" if is_test else "SENKRONİZASYON"
            
            self.log(f"🔄 {operation_name} {operation_type.lower()} başlatılıyor...")
            
            # Seçenekleri log'la
            self.log("⚙️ SEÇENEKLER:")
            if is_test:
                self.log("   🧪 Test Modu: AÇIK")
            if ignore_errors:
                self.log("   🔄 Hata Olduğunda Devam Et: AÇIK")
            
            source_full = f"{source_remote}{source_path}"
            dest_full = f"{dest_remote}{dest_path}"
            
            self.current_process = self.rclone_manager.create_sync_process(
                source_full, dest_full, is_test, ignore_errors
            )
            
            # Process tamamlanmasını bekle
            try:
                stdout, stderr = self.current_process.communicate(timeout=3600)  # 1 saat
                return_code = self.current_process.returncode
            except subprocess.TimeoutExpired:
                self.current_process.kill()
                return_code = -1
                stderr = "Timeout (1 saat)"
            
            # Process'i temizle
            self.rclone_manager.cleanup_process(self.current_process)
            self.current_process = None
            
            if return_code == 0:
                self.log(f"✅ {operation_name} {operation_type.lower()} tamamlandı!")
                result.success_files.append(f"{operation_name} senkronizasyon")
            else:
                error_msg = stderr.strip() if stderr else "Bilinmeyen hata"
                self.log(f"❌ {operation_name} {operation_type.lower()} hatası: {error_msg[:200]}...")
                result.failed_files.append(f"{operation_name} senkronizasyon")
                result.error_details[f"{operation_name} senkronizasyon"] = [error_msg]
            
            # Callback çağır
            if completion_callback:
                completion_callback(result, is_test, return_code == 0)
                
        except Exception as e:
            operation_type = "test" if is_test else "senkronizasyon"
            self.log(f"💥 {operation_type.title()} hatası: {e}")
            result.failed_files.append(f"{operation_name} senkronizasyon")
            result.error_details[f"{operation_name} senkronizasyon"] = [str(e)]
            if completion_callback:
                completion_callback(result, is_test, False)
        finally:
            self.running = False
            self.current_process = None
    
    def delete_files(self, files: List[FileItem], remote: str,
                    completion_callback: Callable = None):
        """Dosyaları sil"""
        if self.running:
            return False
            
        self.running = True
        result = TransferResult()
        
        thread = threading.Thread(
            target=self._delete_worker,
            args=(files, remote, result, completion_callback),
            daemon=False
        )
        thread.start()
        return True
    
    def _delete_worker(self, files: List[FileItem], remote: str,
                      result: TransferResult, completion_callback: Callable = None):
        """Silme worker"""
        try:
            for file_item in files:
                if not self.running:
                    break
                    
                self.log(f"🗑️ Siliniyor: {file_item.name}")
                
                try:
                    path = f"{remote}{file_item.path}"
                    self.current_process = self.rclone_manager.create_delete_process(
                        path, file_item.is_dir
                    )
                    
                    # Process tamamlanmasını bekle
                    try:
                        stdout, stderr = self.current_process.communicate(timeout=600)  # 10 dakika
                        return_code = self.current_process.returncode
                    except subprocess.TimeoutExpired:
                        self.current_process.kill()
                        return_code = -1
                        stderr = "Timeout (10 dakika)"
                    
                    # Process'i temizle
                    self.rclone_manager.cleanup_process(self.current_process)
                    self.current_process = None
                    
                    if return_code == 0:
                        result.success_files.append(file_item.name)
                        self.log(f"✅ Silindi: {file_item.name}")
                    else:
                        error_msg = stderr.strip() if stderr else "Bilinmeyen hata"
                        result.failed_files.append(file_item.name)
                        result.error_details[file_item.name] = [error_msg]
                        self.log(f"❌ Silinemedi: {file_item.name} - {error_msg[:200]}...")
                        
                except Exception as e:
                    result.failed_files.append(file_item.name)
                    result.error_details[file_item.name] = [str(e)]
                    self.log(f"💥 Silme hatası: {file_item.name} - {e}")
            
            # Callback çağır
            if completion_callback:
                completion_callback(result)
                
        except Exception as e:
            self.log(f"💥 Silme hatası: {e}")
        finally:
            self.running = False
            self.current_process = None
    
    def stop_operation(self):
        """İşlemi durdur"""
        self.running = False
        if self.current_process:
            try:
                self.current_process.terminate()
                self.log("🛑 Process sonlandırıldı")
            except:
                pass
        self.log("🛑 İşlem durduruldu")