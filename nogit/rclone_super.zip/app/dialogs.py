"""
Dialog pencereleri ve mesaj kutuları
"""

import tkinter as tk
from tkinter import ttk, scrolledtext, messagebox, filedialog
import webbrowser
from datetime import datetime
from .models import TransferResult


class Dialogs:
    """Dialog ve mesaj pencerelerini yöneten sınıf"""
    
    @staticmethod
    def show_rclone_install_dialog():
        """RClone kurulum dialog'u göster"""
        messagebox.showerror("RClone Gerekli", 
                           "RClone kurulu değil!\n\n"
                           "Kurulum:\n"
                           "Windows: winget install Rclone.Rclone\n"
                           "macOS: brew install rclone\n"
                           "Linux: sudo apt install rclone\n\n"
                           "Program kapatılıyor...")
    
    @staticmethod
    def show_new_connection_dialog(parent, load_remotes_callback):
        """Yeni bağlantı oluştur dialog'u"""
        dialog = tk.Toplevel(parent)
        dialog.title("Yeni Bağlantı")
        dialog.geometry("400x200")
        dialog.resizable(False, False)
        
        ttk.Label(dialog, text="Yeni bağlantı oluşturmak için terminal'de:", 
                 font=('Arial', 12, 'bold')).pack(pady=10)
        
        ttk.Label(dialog, text="rclone config", 
                 font=('Courier', 14), background='lightgray').pack(pady=10)
        
        ttk.Label(dialog, text="komutunu çalıştırın ve rehberi takip edin.").pack(pady=5)
        ttk.Label(dialog, text="Bağlantı oluşturduktan sonra 'Yenile' butonuna basın.").pack(pady=5)
        
        btn_frame = ttk.Frame(dialog)
        btn_frame.pack(pady=20)
        
        ttk.Button(btn_frame, text="📖 Dokümantasyon", 
                  command=lambda: webbrowser.open("https://rclone.org/docs/")).pack(side=tk.LEFT, padx=5)
        ttk.Button(btn_frame, text="🔄 Yenile", 
                  command=lambda: [load_remotes_callback(), dialog.destroy()]).pack(side=tk.LEFT, padx=5)
        ttk.Button(btn_frame, text="❌ Kapat", 
                  command=dialog.destroy).pack(side=tk.RIGHT, padx=5)
    
    @staticmethod
    def show_copy_confirmation(file_names: list, operation_type: str, source: str, 
                              dest: str, test_mode: bool, ignore_existing: bool, 
                              ignore_errors: bool) -> bool:
        """Kopyalama onay dialog'u"""
        message = f"{operation_type} işlemi başlatılacak:\n\n"
        message += f"📋 {len(file_names)} öğe:\n"
        message += "\n".join(file_names[:5])  # İlk 5 öğeyi göster
        if len(file_names) > 5:
            message += f"\n... ve {len(file_names) - 5} öğe daha"
        message += f"\n\n📤 Kaynak: {source}\n📥 Hedef: {dest}\n\n"
        
        # Seçenekleri göster
        message += "⚙️ SEÇENEKLER:\n"
        if test_mode:
            message += "🧪 Test Modu: AÇIK\n"
        if ignore_existing:
            message += "⏭️ Mevcut Dosyaları Atla: AÇIK\n"
        if ignore_errors:
            message += "🔄 Hata Olduğunda Devam Et: AÇIK\n"
        message += "\n"
        
        if test_mode:
            message += "🧪 TEST MODU: Hiçbir dosya değiştirilmeyecek!\n\n"
        else:
            message += "⚠️ Gerçek kopyalama yapılacak!\n\n"
            
        message += "Devam edilsin mi?"
        
        return messagebox.askyesno(f"{operation_type} Onayı", message)
    
    @staticmethod
    def show_sync_confirmation(operation_name: str, test_mode: bool, 
                              ignore_errors: bool, bidirectional: bool = False) -> bool:
        """Senkronizasyon onay dialog'u"""
        operation_type = "TEST" if test_mode else "SENKRONİZASYON"
        
        if bidirectional:
            message = f"İki yönlü {operation_type.lower()} başlatılacak.\n"
            message += "Her iki tarafta da eksik dosyalar tamamlanacak.\n\n"
        else:
            message = f"{operation_name} {operation_type.lower()} başlatılacak.\n"
        
        # Seçenekleri göster
        message += "⚙️ SEÇENEKLER:\n"
        if test_mode:
            message += "🧪 Test Modu: AÇIK\n"
        if ignore_errors:
            message += "🔄 Hata Olduğunda Devam Et: AÇIK\n"
        message += "\n"
        
        if test_mode:
            message += "🧪 TEST MODU: Hiçbir dosya değiştirilmeyecek!\n\n"
        else:
            if not bidirectional:
                message += "⚠️ Hedef tarafta fazla olan dosyalar SİLİNECEK!\n\n"
            else:
                message += "⚠️ Gerçek senkronizasyon yapılacak!\n\n"
            
        message += "Devam edilsin mi?"
        
        return messagebox.askyesno(f"{operation_type} Onayı", message)
    
    @staticmethod
    def show_delete_confirmation(file_names: list, panel_name: str) -> bool:
        """Silme onay dialog'u"""
        message = f"{panel_name.title()} panelde {len(file_names)} öğe silinecek:\n\n"
        message += "\n".join(file_names[:5])
        if len(file_names) > 5:
            message += f"\n... ve {len(file_names) - 5} öğe daha"
        message += "\n\n⚠️ Bu işlem geri alınamaz!\n\nDevam edilsin mi?"
        
        return messagebox.askyesno("Silme Onayı", message)
    
    @staticmethod
    def show_copy_result(success_count: int, total_count: int, is_test: bool, 
                        skipped_count: int = 0, failed_count: int = 0):
        """Kopyalama sonuç dialog'u"""
        operation = "Test" if is_test else "Kopyalama"
        
        if success_count == total_count and failed_count == 0:
            if is_test:
                message = f"Test tamamlandı!\n\n"
                message += f"✅ {success_count} öğe test edildi\n"
                message += f"📋 Toplam: {total_count}"
                if skipped_count > 0:
                    message += f"\n⏭️ {skipped_count} öğe zaten mevcut"
                message += f"\n\n💡 Gerçek kopyalama için Test Modu'nu kapatın"
                messagebox.showinfo("Test Başarılı", message)
            else:
                message = f"Kopyalama tamamlandı!\n{success_count} öğe kopyalandı"
                if skipped_count > 0:
                    message += f"\n{skipped_count} öğe zaten mevcuttu"
                messagebox.showinfo("Başarılı", message)
        else:
            if is_test:
                message = f"Test tamamlandı!\n"
                message += f"✅ Başarılı: {success_count}\n"
                message += f"❌ Hatalı: {failed_count}\n"
                if skipped_count > 0:
                    message += f"⏭️ Atlanan: {skipped_count}\n"
                message += f"📋 Toplam: {total_count}\n\n"
                message += f"📊 Detaylı rapor için 'Rapor' butonuna tıklayın"
                messagebox.showwarning("Test Kısmen Başarılı", message)
            else:
                message = f"Kopyalama tamamlandı!\n"
                message += f"✅ Başarılı: {success_count}\n"
                message += f"❌ Hatalı: {failed_count}\n"
                if skipped_count > 0:
                    message += f"⏭️ Atlanan: {skipped_count}\n"
                message += f"📋 Toplam: {total_count}\n\n"
                message += f"📊 Detaylı rapor için 'Rapor' butonuna tıklayın"
                messagebox.showwarning("Kısmen Başarılı", message)
    
    @staticmethod
    def show_sync_result(success: bool, is_test: bool, operation_name: str, failed_count: int = 0):
        """Senkronizasyon sonuç dialog'u"""
        if success:
            if is_test:
                messagebox.showinfo("Test Başarılı", 
                                  f"{operation_name} test tamamlandı!\n\n"
                                  f"💡 Gerçek senkronizasyon için Test Modu'nu kapatın")
            else:
                messagebox.showinfo("Başarılı", f"{operation_name} senkronizasyon tamamlandı!")
        else:
            operation_type = "TEST" if is_test else "SENKRONİZASYON"
            message = f"{operation_type} hatası!"
            if failed_count > 0:
                message += "\n\nDetaylı rapor için 'Rapor' butonuna tıklayın."
            messagebox.showerror("Hata", message)
    
    @staticmethod
    def show_delete_result(success_count: int, total_count: int, failed_count: int = 0):
        """Silme sonuç dialog'u"""
        if success_count == total_count:
            messagebox.showinfo("Başarılı", f"Silme tamamlandı!\n{success_count} öğe silindi")
        else:
            message = f"Silme tamamlandı!\nSilinen: {success_count}/{total_count}"
            if failed_count > 0:
                message += f"\n\nDetaylı rapor için 'Rapor' butonuna tıklayın."
            messagebox.showwarning("Kısmen Başarılı", message)
    
    @staticmethod
    def show_report_window(parent, transfer_result: TransferResult):
        """İşlem raporu penceresi"""
        if not transfer_result:
            messagebox.showinfo("Rapor", "Henüz bir işlem raporu bulunmuyor.")
            return
            
        # Rapor penceresi oluştur
        report_window = tk.Toplevel(parent)
        report_window.title("İşlem Raporu")
        report_window.geometry("800x600")
        
        # Notebook (sekmeli arayüz)
        notebook = ttk.Notebook(report_window)
        notebook.pack(fill='both', expand=True, padx=10, pady=10)
        
        # Özet sekmesi
        summary_frame = ttk.Frame(notebook)
        notebook.add(summary_frame, text="📊 Özet")
        
        summary_text = scrolledtext.ScrolledText(summary_frame, wrap=tk.WORD)
        summary_text.pack(fill='both', expand=True, padx=5, pady=5)
        
        # Özet bilgileri
        success_count = len(transfer_result.success_files)
        failed_count = len(transfer_result.failed_files)
        skipped_count = len(transfer_result.skipped_files)
        total_count = success_count + failed_count
        
        summary = f"📊 İŞLEM RAPORU\n"
        summary += f"{'='*50}\n\n"
        summary += f"📈 GENEL İSTATİSTİK:\n"
        summary += f"   ✅ Başarılı: {success_count}\n"
        summary += f"   ❌ Hatalı: {failed_count}\n"
        summary += f"   ⏭️ Atlanan: {skipped_count}\n"
        summary += f"   📊 Toplam: {total_count}\n\n"
        
        if success_count > 0:
            success_rate = (success_count / total_count) * 100 if total_count > 0 else 0
            summary += f"   🎯 Başarı Oranı: %{success_rate:.1f}\n\n"
        
        summary += f"📋 BAŞARILI İŞLEMLER ({success_count}):\n"
        if success_count > 0:
            for i, file_name in enumerate(transfer_result.success_files, 1):
                summary += f"   {i:3d}. ✅ {file_name}\n"
        else:
            summary += "   (Başarılı işlem bulunmuyor)\n"
            
        summary_text.insert(tk.END, summary)
        summary_text.config(state='disabled')
        
        # Hata sekmesi (eğer hata varsa)
        if failed_count > 0:
            error_frame = ttk.Frame(notebook)
            notebook.add(error_frame, text=f"❌ Hatalar ({failed_count})")
            
            error_text = scrolledtext.ScrolledText(error_frame, wrap=tk.WORD)
            error_text.pack(fill='both', expand=True, padx=5, pady=5)
            
            error_report = f"❌ HATA RAPORU\n"
            error_report += f"{'='*50}\n\n"
            
            for i, file_name in enumerate(transfer_result.failed_files, 1):
                error_report += f"{i:3d}. ❌ {file_name}\n"
                
                if file_name in transfer_result.error_details:
                    errors = transfer_result.error_details[file_name]
                    for error in errors:
                        error_report += f"     💬 {error}\n"
                error_report += "\n"
                
            error_text.insert(tk.END, error_report)
            error_text.config(state='disabled')
        
        # Atlanan dosyalar sekmesi (eğer varsa)
        if skipped_count > 0:
            skipped_frame = ttk.Frame(notebook)
            notebook.add(skipped_frame, text=f"⏭️ Atlanan ({skipped_count})")
            
            skipped_text = scrolledtext.ScrolledText(skipped_frame, wrap=tk.WORD)
            skipped_text.pack(fill='both', expand=True, padx=5, pady=5)
            
            skipped_report = f"⏭️ ATLANAN DOSYALAR RAPORU\n"
            skipped_report += f"{'='*50}\n\n"
            skipped_report += f"Bu dosyalar zaten mevcut olduğu için atlandı:\n\n"
            
            for i, skipped_msg in enumerate(transfer_result.skipped_files, 1):
                skipped_report += f"{i:3d}. ⏭️ {skipped_msg}\n"
                
            skipped_text.insert(tk.END, skipped_report)
            skipped_text.config(state='disabled')
        
        # Kapatma butonu
        btn_frame = ttk.Frame(report_window)
        btn_frame.pack(side=tk.BOTTOM, fill=tk.X, padx=10, pady=5)
        
        ttk.Button(btn_frame, text="📋 Raporu Kaydet", 
                  command=lambda: Dialogs._save_report(report_window, transfer_result)).pack(side=tk.LEFT, padx=5)
        ttk.Button(btn_frame, text="❌ Kapat", 
                  command=report_window.destroy).pack(side=tk.RIGHT, padx=5)
    
    @staticmethod
    def _save_report(parent_window, transfer_result: TransferResult):
        """Raporu dosyaya kaydet"""
        filename = filedialog.asksaveasfilename(
            parent=parent_window,
            title="Raporu Kaydet",
            defaultextension=".txt",
            filetypes=[("Metin Dosyaları", "*.txt"), ("Tüm Dosyalar", "*.*")]
        )
        
        if filename:
            try:
                success_count = len(transfer_result.success_files)
                failed_count = len(transfer_result.failed_files)
                skipped_count = len(transfer_result.skipped_files)
                total_count = success_count + failed_count
                
                with open(filename, 'w', encoding='utf-8') as f:
                    f.write("DUAL PANE RCLONE MANAGER v1.4 - İŞLEM RAPORU\n")
                    f.write(f"Tarih: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
                    f.write("="*60 + "\n\n")
                    
                    f.write("GENEL İSTATİSTİK:\n")
                    f.write(f"  Başarılı: {success_count}\n")
                    f.write(f"  Hatalı: {failed_count}\n")
                    f.write(f"  Atlanan: {skipped_count}\n")
                    f.write(f"  Toplam: {total_count}\n")
                    
                    if total_count > 0:
                        success_rate = (success_count / total_count) * 100
                        f.write(f"  Başarı Oranı: %{success_rate:.1f}\n")
                    f.write("\n")
                    
                    if success_count > 0:
                        f.write(f"BAŞARILI İŞLEMLER ({success_count}):\n")
                        for i, file_name in enumerate(transfer_result.success_files, 1):
                            f.write(f"  {i:3d}. {file_name}\n")
                        f.write("\n")
                    
                    if failed_count > 0:
                        f.write(f"HATA RAPORU ({failed_count}):\n")
                        for i, file_name in enumerate(transfer_result.failed_files, 1):
                            f.write(f"  {i:3d}. {file_name}\n")
                            if file_name in transfer_result.error_details:
                                errors = transfer_result.error_details[file_name]
                                for error in errors:
                                    f.write(f"       HATA: {error}\n")
                            f.write("\n")
                    
                    if skipped_count > 0:
                        f.write(f"ATLANAN DOSYALAR ({skipped_count}):\n")
                        for i, skipped_msg in enumerate(transfer_result.skipped_files, 1):
                            f.write(f"  {i:3d}. {skipped_msg}\n")
                        f.write("\n")
                
                messagebox.showinfo("Başarılı", f"Rapor kaydedildi:\n{filename}")
                
            except Exception as e:
                messagebox.showerror("Hata", f"Rapor kaydedilemedi:\n{e}")
    
    @staticmethod
    def show_help(parent=None):
        """Yardım penceresi"""
        help_text = """
DUAL PANE RCLONE FILE MANAGER v1.4 - KULLANIM KILAVUZU

🆕 v1.4 YENİLİKLERİ:
• ⚙️ Kullanıcı Kontrollü Seçenekler
• ⏭️ "Mevcut Dosyaları Atla" checkbox (--ignore-existing)
• 🔄 "Hata Olduğunda Devam Et" checkbox (--ignore-errors)
• 🧪 Test modu ile birlikte özelleştirilebilir davranış
• 📊 Seçenekler onay dialog'larında ve log'larda görünür

🔗 BAĞLANTI KURMA:
• "Yeni Bağlantı" butonuna tıklayın
• Terminal'de "rclone config" komutunu çalıştırın
• Bağlantı türünü seçin ve rehberi takip edin
• Bağlantı kurulduktan sonra dropdown'dan seçin

📁 DOSYA İŞLEMLERİ:
• Çift tıklama: Klasöre gir
• Tek tıklama: Dosya/klasör seç
• Sağ tıklama: Context menü

⚙️ YENİ SEÇENEKLER SİSTEMİ:
• 🧪 Test Modu: Tüm işlemler --dry-run ile çalışır
• ⏭️ Mevcut Dosyaları Atla: Var olan dosyalar üzerine yazılmaz
• 🔄 Hata Olduğunda Devam Et: Bir dosyada hata olsa bile devam eder
• Seçenekler gerçek zamanlı değiştirilebilir
• Her değişiklik log'a yazılır

📤 KOPYALAMA (GELİŞTİRİLMİŞ):
• Varsayılan: Mevcut dosyalar atlanır, hatalar göz ardı edilir
• Test modu ile güvenli deneme
• Kullanıcı kontrollü --ignore-existing ve --ignore-errors
• 30 dakika timeout
• Detaylı onay dialog'u ile seçenekleri gösterir

🔄 SENKRONİZASYON (GELİŞTİRİLMİŞ):
• İki Yönlü: copy komutu kullanır (silme yok)
• Tek Yönlü: sync komutu kullanır (fazla dosyalar silinir)
• Kullanıcı kontrollü hata yönetimi
• Test modu ile güvenli deneme
• 1 saat timeout

🗑️ SİLME:
• Test modunda silme yapılamaz
• Bu işlem geri alınamaz
• 10 dakika timeout

📊 RAPOR SİSTEMİ:
• Her işlem sonrası detaylı rapor
• Başarılı/Hatalı/Atlanan dosya listeleri
• Hata detayları ve sebepleri
• Başarı oranı hesaplama
• Raporu TXT dosyası olarak kaydetme

⏱️ ZAMAN ASIMLARI:
• Dosya listeleme: 2 dakika
• Dosya kopyalama: 30 dakika  
• Senkronizasyon: 1 saat
• Silme işlemi: 10 dakika

💡 KULLANIM İPUÇLARI:
• Seçenekleri ihtiyacınıza göre ayarlayın
• Büyük işlemler öncesi Test Modu'nu açın
• "Mevcut Dosyaları Atla" çoğu zaman açık kalabilir
• "Hata Olduğunda Devam Et" büyük klasörlerde faydalıdır
• Onay dialog'larında seçeneklerinizi kontrol edin
• Rapor sistemini kullanarak sonuçları takip edin
• Log panelini açık tutarak canlı takip yapın

🔧 PARAMETRE AÇIKLAMALARI:
• --ignore-existing: Hedefte var olan dosyaları kopyalamaz
• --ignore-errors: Hata oluştuğunda durdurmaz, devam eder
• --dry-run: Test modu, hiçbir dosyayı değiştirmez
• --verbose: Detaylı çıktı verir
• sync vs copy: sync fazla dosyaları siler, copy silmez
        """
        
        help_window = tk.Toplevel(parent) if parent else tk.Toplevel()
        help_window.title("Kullanım Kılavuzu")
        help_window.geometry("800x750")
        
        help_text_widget = scrolledtext.ScrolledText(help_window, wrap=tk.WORD)
        help_text_widget.pack(fill='both', expand=True, padx=10, pady=10)
        help_text_widget.insert(tk.END, help_text)
        help_text_widget.config(state='disabled')
    
    @staticmethod
    def show_about():
        """Hakkında dialog'u"""
        messagebox.showinfo("Hakkında", 
                          "Dual Pane RClone File Manager v1.4\n\n"
                          "İki panelli dosya yöneticisi ile\n"
                          "bulut depolama servisleri arasında\n"
                          "kolay dosya transferi.\n\n"
                          "✨ v1.4 Yenilikleri:\n"
                          "⚙️ Kullanıcı kontrollü seçenekler\n"
                          "⏭️ Mevcut dosyaları atla checkbox\n"
                          "🔄 Hata olduğunda devam et checkbox\n"
                          "📋 Geliştirilmiş onay dialog'ları\n"
                          "🔧 Gerçek zamanlı parametre kontrolü\n\n"
                          "RClone tabanlı • Python 3.8+\n"
                          "https://rclone.org")
    
    @staticmethod
    def show_preferences():
        """Seçenekler dialog'u (gelecek versiyon için)"""
        messagebox.showinfo("Seçenekler", "Seçenekler henüz hazır değil.\nGelecek versiyonda eklenecek.")
    
    @staticmethod
    def show_rclone_config():
        """RClone yapılandırması"""
        messagebox.showinfo("RClone Yapılandırması", 
                          "Terminal'de şu komutu çalıştırın:\n\n"
                          "rclone config\n\n"
                          "Yapılandırma sonrası programı yenileyin.")
    
    @staticmethod
    def show_remotes_list(remotes: list):
        """Bağlantı listesi"""
        if remotes:
            remote_list = "\n".join([f"• {r}" for r in remotes])
            messagebox.showinfo("Mevcut Bağlantılar", f"Toplam {len(remotes)} bağlantı:\n\n{remote_list}")
        else:
            messagebox.showinfo("Bağlantılar", "Henüz yapılandırılmış bağlantı yok.")
    
    @staticmethod
    def show_test_mode_warning():
        """Test modunda silme uyarısı"""
        messagebox.showwarning("Test Modu", 
                             "Test modundayken silme işlemi yapılamaz!\n\n"
                             "Test Modu'nu kapatın ve tekrar deneyin.")
    
    @staticmethod
    def show_no_selection_warning():
        """Seçim yapılmadı uyarısı"""
        messagebox.showwarning("Uyarı", "Dosya/klasör seçin!")
    
    @staticmethod
    def show_no_connection_error():
        """Bağlantı yok hatası"""
        messagebox.showerror("Hata", "Her iki panel de bağlı olmalı!")
    
    @staticmethod
    def show_operation_running_warning():
        """İşlem devam ediyor uyarısı"""
        messagebox.showwarning("Uyarı", "Başka bir işlem devam ediyor!")
    
    @staticmethod
    def confirm_exit_with_operation():
        """İşlem devam ederken çıkış onayı"""
        return messagebox.askokcancel("Çıkış", "Bir işlem devam ediyor. Çıkmak istediğinizden emin misiniz?")