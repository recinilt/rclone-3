# Dual Pane RClone File Manager v1.4

İki panelli dosya yöneticisi ile bulut depolama servisleri arasında kolay dosya transferi.

## 🆕 v1.4 Yenilikleri

- ⚙️ **Kullanıcı Kontrollü Seçenekler**: Artık işlemlerinizi daha iyi kontrol edin
- ⏭️ **Mevcut Dosyaları Atla**: `--ignore-existing` parametresi için checkbox
- 🔄 **Hata Olduğunda Devam Et**: `--ignore-errors` parametresi için checkbox  
- 🧪 **Geliştirilmiş Test Modu**: Seçeneklerle birlikte çalışır
- 📋 **Detaylı Onay Dialog'ları**: Seçeneklerinizi işlem öncesi görebilirsiniz
- 🔧 **Gerçek Zamanlı Kontrol**: Seçenekleri anında değiştirebilirsiniz
- 🛡️ **Geliştirilmiş Thread Yönetimi**: Program kapanma sorunları çözüldü

## 📋 Gereksinimler

- **Python 3.8** veya üstü
- **RClone** kurulu olmalı

### RClone Kurulumu

```bash
# Windows
winget install Rclone.Rclone

# macOS  
brew install rclone

# Linux (Ubuntu/Debian)
sudo apt install rclone

# Linux (CentOS/RHEL)
sudo yum install rclone
```

## 🚀 Kurulum ve Çalıştırma

### 1. Dosya Yapısı
```
dual_pane_rclone/
├── main.py                 # Ana program
├── README.md              # Bu dosya
└── app/
    ├── __init__.py        # Paket başlatma
    ├── dual_pane_manager.py  # Ana uygulama sınıfı
    ├── models.py          # Veri modelleri
    ├── rclone_service.py  # RClone işlemleri
    ├── ui_components.py   # UI bileşenleri
    ├── transfer_operations.py  # Transfer işlemleri
    └── dialogs.py         # Dialog pencereleri
```

### 2. Çalıştırma
```bash
cd dual_pane_rclone
python main.py
```

### 3. İlk Kullanım

1. **RClone Bağlantısı Ekleyin**:
   - "Yeni Bağlantı" butonuna tıklayın
   - Terminal'de `rclone config` komutunu çalıştırın
   - Rehberi takip ederek bağlantı kurun

2. **Panelleri Yapılandırın**:
   - Sol ve sağ panelde dropdown'dan bağlantıları seçin
   - Klasörlere çift tıklayarak gezinin

3. **Seçenekleri Ayarlayın**:
   - 🧪 **Test Modu**: Güvenli deneme için
   - ⏭️ **Mevcut Dosyaları Atla**: Var olan dosyalar üzerine yazılmaz
   - 🔄 **Hata Olduğunda Devam Et**: Bir hatada durma

## 🎯 Özellikler

### ⚙️ Yeni Seçenekler Sistemi

- **Test Modu (🧪)**: Tüm işlemler `--dry-run` ile çalışır, hiçbir dosya değişmez
- **Mevcut Dosyaları Atla (⏭️)**: `--ignore-existing` - Hedefte var olan dosyaları atlar
- **Hata Olduğunda Devam Et (🔄)**: `--ignore-errors` - Hatalar durdurmaz
- **Gerçek Zamanlı Değişiklik**: Seçenekleri işlem sırasında değiştirebilirsiniz
- **Detaylı Onay**: Her işlem öncesi seçeneklerinizi görürsünüz

### 📤 Kopyalama İşlemleri

- **Soldan Sağa/Sağdan Sola**: Dosya ve klasörleri kopyalayın
- **Çoklu Seçim**: Birden fazla öğeyi aynı anda kopyalayın
- **Canlı İlerleme**: İşlemleri gerçek zamanlı takip edin
- **30 Dakika Timeout**: Büyük dosyalar için uygun zaman limiti

### 🔄 Senkronizasyon

- **İki Yönlü**: `copy` komutu kullanır (silme yok, sadece eksik dosyalar eklenir)
- **Tek Yönlü**: `sync` komutu kullanır (hedefte fazla dosyalar silinir)
- **1 Saat Timeout**: Büyük klasörler için uygun zaman limiti

### 🗑️ Silme İşlemleri  

- **Güvenli Silme**: Test modunda silme yapılamaz
- **Onay Dialog'u**: Her silme işlemi öncesi onay
- **Geri Alınamaz**: Bu işlem geri alınamaz uyarısı

### 📊 Rapor Sistemi

- **Detaylı Raporlar**: Başarılı/Hatalı/Atlanan dosya listeleri
- **Hata Analizi**: Hangi dosyada ne hatası olduğunu görün
- **Başarı Oranı**: İstatistiksel bilgiler
- **Rapor Kaydetme**: TXT dosyası olarak kaydedin

## 🔧 Kullanım İpuçları

### 💡 Seçenekler Nasıl Kullanılır?

1. **Test Modu**: Büyük işlemler öncesi mutlaka test edin
2. **Mevcut Dosyaları Atla**: Çoğu zaman açık bırakabilirsiniz
3. **Hata Olduğunda Devam Et**: Büyük klasörlerde faydalıdır
4. **Onay Dialog'ları**: İşlem öncesi seçeneklerinizi kontrol edin

### 🚀 Performans İpuçları

- **Küçük Dosyalar**: Transfer sayısını artırın
- **Büyük Dosyalar**: Tek seferde kopyalayın  
- **Ağ Problemleri**: "Hata Olduğunda Devam Et"i açın
- **Disk Alanı**: "Mevcut Dosyaları Atla"yı açın

### 🛠️ Sorun Giderme

**Program kapanmıyor:**
- v1.4'te çözülmüştür. Thread yönetimi iyileştirildi.

**RClone bulunamıyor:**
- RClone'un PATH'te olduğundan emin olun
- Terminal'de `rclone version` test edin

**Transfer yavaş:**
- İnternet bağlantınızı kontrol edin
- `--transfers` sayısını ayarlayın (gelecek versiyonda)

**Hata mesajları:**
- Log panelini açık tutun
- Rapor sistemini kullanın
- Test modu ile deneyin

## 📝 Desteklenen Servisler

### 📁 Bulut Depolama
- Google Drive, OneDrive, Dropbox
- Box, MEGA, pCloud  
- Koofr, Yandex Disk

### ☁️ Kurumsal Bulut
- Amazon S3, Azure Blob Storage
- Google Cloud Storage, Backblaze B2
- Wasabi

### 🌐 Protokoller
- FTP, SFTP/SSH, WebDAV

### 💾 Yerel/Ağ
- Yerel klasörler, SMB/CIFS

## ⏱️ Zaman Aşımları

- **Dosya Listeleme**: 2 dakika
- **Dosya Kopyalama**: 30 dakika  
- **Senkronizasyon**: 1 saat
- **Silme İşlemi**: 10 dakika

## 🔧 RClone Parametreleri

### Kullanılan Parametreler
- `--ignore-existing`: Mevcut dosyaları atla
- `--ignore-errors`: Hata olduğunda devam et
- `--dry-run`: Test modu
- `--verbose`: Detaylı çıktı
- `--progress`: İlerleme göster
- `--transfers`: Eşzamanlı transfer sayısı

### Komut Örnekleri
```bash
# Test kopyalama
rclone copy source: dest: --dry-run --ignore-existing --verbose

# Gerçek kopyalama  
rclone copy source: dest: --ignore-existing --ignore-errors --progress

# Senkronizasyon
rclone sync source: dest: --ignore-errors --verbose
```

## 🎯 Klavye Kısayolları

- **F5**: Paneli yenile
- **Ctrl+C**: İşlemi durdur  
- **Delete**: Seçili öğeyi sil
- **Enter**: Klasöre gir
- **Çift Tık**: Klasöre gir / Dosya seç

## 🔍 Gelecek Versiyonlar

- **v1.5**: Özelleştirilebilir transfer parametreleri
- **v1.6**: Bağlantı şablonları ve favoriler
- **v1.7**: Bandwidth limitleri
- **v1.8**: Çoklu panel desteği

## 📞 Destek

- **RClone Dokümantasyonu**: https://rclone.org/docs/
- **Test Modu**: Her zaman ilk önce test edin
- **Log Panel**: Sorunları takip edin
- **Rapor Sistemi**: Hataları analiz edin

## 📄 Lisans

Bu proje RClone tabanlıdır. RClone'un lisansı: MIT License

---

**Dual Pane RClone File Manager v1.4** - Güvenli, hızlı ve kullanışlı bulut dosya yönetimi!