# Dual Pane RClone File Manager v1.4.1

İki panelli dosya yöneticisi ile bulut depolama servisleri arasında kolay dosya transferi.

## 🆕 v1.4.1 Yenilikleri

- 🧙‍♂️ **GUI Bağlantı Sihirbazı**: Adım adım rehberli bağlantı oluşturma
- 🖥️ **Otomatik Terminal Entegrasyonu**: Terminal'de rclone config otomatik açılır
- 🔗 **Geliştirilmiş Bağlantı Yönetimi**: İki seçenek - Kolay GUI veya güçlü Terminal
- ⚙️ **Akıllı Servis Tanıma**: Popüler servislerin önceden yapılandırılmış ayarları
- 🎯 **Kolay Kurulum**: Yeni kullanıcılar için basitleştirilmiş deneyim
- 🔧 **Mevcut Özellikler Korundu**: Tüm v1.4 özellikleri aynen çalışıyor

## 🆕 v1.4 Önceki Yenilikleri

- ⚙️ **Kullanıcı Kontrollü Seçenekler**: Artık işlemlerinizi daha iyi kontrol edin
- ⏭️ **Mevcut Dosyaları Atla**: `--ignore-existing` parametresi için checkbox
- 🔄 **Hata Olduğunda Devam Et**: `--ignore-errors` parametresi için checkbox  
- 🧪 **Geliştirilmiş Test Modu**: Seçeneklerle birlikte çalışır
- 📋 **Detaylı Onay Dialog'ları**: Seçeneklerinizi işlem öncesi görebilirsiniz
- 🔧 **Gerçek Zamanlı Kontrol**: Seçenekleri anında değiştirebilirsiniz
- 🛡️ **Geliştirilmiş Thread Yönetimi**: Program kapanma sorunları çözüldü

## 📋 Gereksinimler

- **Python 3.8** veya üstü
- **RClone** kurulu olmalı

### RClone Kurulumu

```bash
# Windows
winget install Rclone.Rclone

# macOS  
brew install rclone

# Linux (Ubuntu/Debian)
sudo apt install rclone

# Linux (CentOS/RHEL)
sudo yum install rclone
```

## 🚀 Kurulum ve Çalıştırma

### 1. Dosya Yapısı
```
dual_pane_rclone/
├── main.py                 # Ana program
├── README.md              # Bu dosya
└── app/
    ├── __init__.py        # Paket başlatma
    ├── dual_pane_manager.py  # Ana uygulama sınıfı
    ├── models.py          # Veri modelleri
    ├── rclone_service.py  # RClone işlemleri
    ├── ui_components.py   # UI bileşenleri
    ├── transfer_operations.py  # Transfer işlemleri
    └── dialogs.py         # Dialog pencereleri
```

### 2. Çalıştırma
```bash
cd dual_pane_rclone
python main.py
```

### 3. İlk Kullanım - YENİ VE GELİŞTİRİLMİŞ!

**🧙‍♂️ SEÇENEK 1: GUI Sihirbazı (ÖNERİLEN)**:
1. "Yeni Bağlantı" butonuna tıklayın
2. "Seçenek 2: Guided Yapılandırma Sihirbazı" → "🧙‍♂️ Sihirbazı Başlat"
3. Kullanmak istediğiniz servisi seçin (Google Drive, OneDrive, Dropbox vs.)
4. Bağlantı adını girin
5. Gerekli ayarları yapın (çoğu otomatik)
6. "Bitir" ile yapılandırmayı tamamlayın

**🖥️ SEÇENEK 2: Terminal ile (İLERİ SEVİYE)**:
1. "Yeni Bağlantı" butonuna tıklayın  
2. "Seçenek 1: Terminal ile Yapılandırma" → "🖥️ Terminal Aç"
3. Otomatik açılan terminal'de `rclone config` rehberini takip edin
4. Bağlantı oluşturduktan sonra "🔄 Bağlantıları Yenile" butonuna basın

**📁 PANEL KULLANIMI**:
1. Sol ve sağ panelde dropdown'dan bağlantıları seçin
2. Klasörlere çift tıklayarak gezinin
3. Seçenekleri ihtiyacınıza göre ayarlayın

## 🎯 Özellikler

### 🧙‍♂️ YENİ: Akıllı Bağlantı Sihirbazı

- **📋 Servis Kategorileri**: Popüler Bulut, Diğer Bulut, Protokoller, Yerel/Ağ
- **🎯 Otomatik Yapılandırma**: Google Drive, OneDrive, Dropbox için özel ayarlar
- **💡 Akıllı Öneriler**: Her servis için optimum ayar önerileri
- **🔐 OAuth Desteği**: Kolay ve güvenli kimlik doğrulama
- **📱 Canlı Test**: Bağlantı oluşturulduktan sonra otomatik test
- **⚡ Hızlı Kurulum**: 3-5 dakikada kullanıma hazır

### 🖥️ YENİ: Otomatik Terminal Entegrasyonu

- **🪟 Windows**: CMD otomatik açılır, rclone config çalışır
- **🍎 macOS**: Terminal.app entegrasyonu  
- **🐧 Linux**: gnome-terminal, xterm, konsole desteği
- **🔄 Otomatik Yenileme**: Terminal kapatıldıktan sonra bağlantılar güncellenir
- **🛡️ Hata Yönetimi**: Terminal bulunamadığında manuel talimatlar

### ⚙️ Geliştirilmiş Seçenekler Sistemi

- **Test Modu (🧪)**: Tüm işlemler `--dry-run` ile çalışır, hiçbir dosya değişmez
- **Mevcut Dosyaları Atla (⏭️)**: `--ignore-existing` - Hedefte var olan dosyaları atlar
- **Hata Olduğunda Devam Et (🔄)**: `--ignore-errors` - Hatalar durdurmaz
- **Gerçek Zamanlı Değişiklik**: Seçenekleri işlem sırasında değiştirebilirsiniz
- **Detaylı Onay**: Her işlem öncesi seçeneklerinizi görürsünüz

### 📤 Kopyalama İşlemleri

- **Soldan Sağa/Sağdan Sola**: Dosya ve klasörleri kopyalayın
- **Çoklu Seçim**: Birden fazla öğeyi aynı anda kopyalayın
- **Canlı İlerleme**: İşlemleri gerçek zamanlı takip edin
- **30 Dakika Timeout**: Büyük dosyalar için uygun zaman limiti

### 🔄 Senkronizasyon

- **İki Yönlü**: `copy` komutu kullanır (silme yok, sadece eksik dosyalar eklenir)
- **Tek Yönlü**: `sync` komutu kullanır (hedefte fazla dosyalar silinir)
- **1 Saat Timeout**: Büyük klasörler için uygun zaman limiti

### 🗑️ Silme İşlemleri  

- **Güvenli Silme**: Test modunda silme yapılamaz
- **Onay Dialog'u**: Her silme işlemi öncesi onay
- **Geri Alınamaz**: Bu işlem geri alınamaz uyarısı

### 📊 Rapor Sistemi

- **Detaylı Raporlar**: Başarılı/Hatalı/Atlanan dosya listeleri
- **Hata Analizi**: Hangi dosyada ne hatası olduğunu görün
- **Başarı Oranı**: İstatistiksel bilgiler
- **Rapor Kaydetme**: TXT dosyası olarak kaydedin

## 🔧 Desteklenen Servisler

### 📁 Popüler Bulut Depolama (GUI Sihirbazı Destekli)
- **Google Drive** - OAuth entegrasyonu, otomatik ayarlar
- **Microsoft OneDrive** - Personal/Business hesap desteği
- **Dropbox** - OAuth entegrasyonu, hızlı kurulum
- **Box** - İş odaklı depolama, OAuth desteği

### ☁️ Diğer Bulut Servisleri
- **MEGA** - Şifreli depolama, yüksek güvenlik
- **pCloud** - Avrupa merkezli, GDPR uyumlu
- **Yandex Disk** - Rusya merkezli, büyük depolama
- **Koofr** - Slovenya merkezli, gizlilik odaklı

### 🌐 Protokoller
- **FTP** - Klasik dosya transfer protokolü
- **SFTP/SSH** - Güvenli dosya transfer
- **WebDAV** - Web tabanlı dosya erişimi

### 💾 Yerel/Ağ
- **Yerel Klasör** - Bilgisayarınızdaki klasörler
- **SMB/CIFS** - Windows ağ paylaşımları

### ☁️ Kurumsal Bulut (İleri Seviye)
- Amazon S3, Azure Blob Storage
- Google Cloud Storage, Backblaze B2
- Wasabi

## 💡 Yeni Kullanıcı Rehberi

### 🚀 5 Dakikada Başlayın

1. **Program Başlatın**: `python main.py`
2. **İlk Bağlantıyı Oluşturun**: 
   - "🔗 Yeni Bağlantı" → "🧙‍♂️ Sihirbazı Başlat"
   - Google Drive veya OneDrive seçin (en kolay)
   - Bağlantı adı girin (örn: "benim_drive")
   - "✅ Bitir" ile tamamlayın
3. **İkinci Bağlantı** (isteğe bağlı):
   - Başka bir bulut servis veya yerel klasör
4. **İlk Transfer**:
   - Sol/sağ panelde bağlantıları seçin
   - Dosya seçip "➡️ Sol → Sağ" ile kopyalayın
   - 🧪 Test modu ile önce deneyin!

### 🔧 Kullanım İpuçları

**⚙️ Seçenekler Nasıl Kullanılır?**

1. **Test Modu**: Büyük işlemler öncesi mutlaka test edin
2. **Mevcut Dosyaları Atla**: Çoğu zaman açık bırakabilirsiniz
3. **Hata Olduğunda Devam Et**: Büyük klasörlerde faydalıdır
4. **Onay Dialog'ları**: İşlem öncesi seçeneklerinizi kontrol edin

**🚀 Performans İpuçları**

- **Küçük Dosyalar**: Transfer sayısını artırın
- **Büyük Dosyalar**: Tek seferde kopyalayın  
- **Ağ Problemleri**: "Hata Olduğunda Devam Et"i açın
- **Disk Alanı**: "Mevcut Dosyaları Atla"yı açın

**🛠️ Sorun Giderme**

**Bağlantı oluşturulamıyor:**
- GUI sihirbazında adımları takip edin
- Terminal seçeneğini deneyin
- İnternet bağlantınızı kontrol edin

**Program kapanmıyor:**
- v1.4.1'de çözülmüştür. Thread yönetimi iyileştirildi.

**RClone bulunamıyor:**
- RClone'un PATH'te olduğundan emin olun
- Terminal'de `rclone version` test edin

**Transfer yavaş:**
- İnternet bağlantınızı kontrol edin
- `--transfers` sayısını ayarlayın (gelecek versiyonda)

**Hata mesajları:**
- Log panelini açık tutun
- Rapor sistemini kullanın
- Test modu ile deneyin

## ⏱️ Zaman Aşımları

- **Dosya Listeleme**: 2 dakika
- **Dosya Kopyalama**: 30 dakika  
- **Senkronizasyon**: 1 saat
- **Silme İşlemi**: 10 dakika

## 🔧 RClone Parametreleri

### Kullanılan Parametreler
- `--ignore-existing`: Mevcut dosyaları atla
- `--ignore-errors`: Hata olduğunda devam et
- `--dry-run`: Test modu
- `--verbose`: Detaylı çıktı
- `--progress`: İlerleme göster
- `--transfers`: Eşzamanlı transfer sayısı

### Komut Örnekleri
```bash
# Test kopyalama
rclone copy source: dest: --dry-run --ignore-existing --verbose

# Gerçek kopyalama  
rclone copy source: dest: --ignore-existing --ignore-errors --progress

# Senkronizasyon
rclone sync source: dest: --ignore-errors --verbose
```

## 🎯 Klavye Kısayolları

- **F5**: Paneli yenile
- **Ctrl+C**: İşlemi durdur  
- **Delete**: Seçili öğeyi sil
- **Enter**: Klasöre gir
- **Çift Tık**: Klasöre gir / Dosya seç

## 🔍 Gelecek Versiyonlar

- **v1.5**: Özelleştirilebilir transfer parametreleri
- **v1.6**: Bağlantı şablonları ve favoriler
- **v1.7**: Bandwidth limitleri
- **v1.8**: Çoklu panel desteği
- **v1.9**: Daha fazla servis için GUI sihirbazı

## 📞 Destek

- **RClone Dokümantasyonu**: https://rclone.org/docs/
- **Test Modu**: Her zaman ilk önce test edin
- **Log Panel**: Sorunları takip edin
- **Rapor Sistemi**: Hataları analiz edin
- **GUI Sihirbazı**: Yeni kullanıcılar için kolay kurulum

## 📄 Lisans

Bu proje RClone tabanlıdır. RClone'un lisansı: MIT License

## 🎉 Teşekkürler

- **RClone Team**: Harika araç için teşekkürler
- **Python Community**: Tkinter ve diğer kütüphaneler için
- **Kullanıcılar**: Geri bildirimler ve öneriler için

---

**Dual Pane RClone File Manager v1.4.1** - Artık daha kolay, daha hızlı ve daha güvenli bulut dosya yönetimi!

### 🌟 Bu Versiyonun Öne Çıkan Özellikleri:

1. **🧙‍♂️ GUI Sihirbazı**: Teknik bilgi gerektirmeden bağlantı oluşturma
2. **🖥️ Terminal Entegrasyonu**: İleri kullanıcılar için güçlü kontrol
3. **⚡ 5 Dakikada Kurulum**: Yeni kullanıcılar için hızlı başlangıç
4. **🔧 Mevcut Özellikler Korundu**: Hiçbir özellik kaybedilmedi
5. **📱 Modern Arayüz**: Daha kullanışlı ve anlaşılır tasarım

### 🎯 Kimler İçin Uygun:

- **👨‍💼 İş Kullanıcıları**: Bulut servisleri arası dosya transferi
- **👩‍💻 Geliştiriciler**: Backup ve senkronizasyon işlemleri
- **🏠 Ev Kullanıcıları**: Kişisel dosya yönetimi
- **🎓 Öğrenciler**: Okul projeleri ve ödevi paylaşımı
- **🏢 Küçük İşletmeler**: Dosya yedekleme ve arşivleme

### 🚀 Neden Bu Program?

✅ **Kolay Kullanım**: GUI sihirbazı ile kurulum  
✅ **Güvenli**: Test modu ile risk-free işlemler  
✅ **Hızlı**: Çoklu transfer desteği  
✅ **Detaylı**: Kapsamlı raporlama sistemi  
✅ **Ücretsiz**: Açık kaynak ve bedava  
✅ **Çok Servis**: 20+ bulut servisi desteği  
✅ **Modern**: Sürekli güncellenen teknoloji