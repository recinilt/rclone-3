#!/usr/bin/env python3
"""
Dual Pane RClone File Manager v1.4 - Ana Program
İki panelli dosya yöneticisi ile görsel dosya transferi
"""

import sys
import signal
from app.dual_pane_manager import DualPaneRCloneManager


def signal_handler(signum, frame):
    """Sinyal yakalayıcı (Ctrl+C)"""
    print("\n👋 Program kapatılıyor...")
    sys.exit(0)


def main():
    """Ana program fonksiyonu"""
    print("🚀 Dual Pane RClone File Manager v1.4 başlatılıyor...")
    
    # Sinyal yakalayıcıları kur
    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)
    
    # Python versiyon kontrolü
    if sys.version_info < (3, 8):
        print("❌ Bu program Python 3.8 veya üstü gerektirir!")
        print(f"   Mevcut versiyon: {sys.version}")
        sys.exit(1)
    
    try:
        app = DualPaneRCloneManager()
        app.run()
    except KeyboardInterrupt:
        print("\n👋 Program kapatılıyor...")
        sys.exit(0)
    except Exception as e:
        print(f"💥 Program hatası: {e}")
        input("Çıkmak için Enter'a basın...")
        sys.exit(1)


if __name__ == "__main__":
    main()