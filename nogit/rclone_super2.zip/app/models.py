"""
Veri modelleri ve sınıfları
"""

from typing import Dict, List


class RCloneService:
    """RClone servis tanımı"""
    def __init__(self, name: str, display_name: str, category: str, 
                 needs_client_id: bool = False, needs_client_secret: bool = False,
                 config_template: Dict = None, notes: str = ""):
        self.name = name
        self.display_name = display_name
        self.category = category
        self.needs_client_id = needs_client_id
        self.needs_client_secret = needs_client_secret
        self.config_template = config_template or {}
        self.notes = notes


class FileItem:
    """Dosya/klasör öğesi"""
    def __init__(self, name: str, path: str, is_dir: bool, size: str = "", 
                 modified: str = "", remote: str = ""):
        self.name = name
        self.path = path
        self.is_dir = is_dir
        self.size = size
        self.modified = modified
        self.remote = remote


class TransferResult:
    """Transfer sonucu bilgileri"""
    def __init__(self):
        self.success_files = []
        self.failed_files = []
        self.skipped_files = []
        self.error_details = {}


def initialize_services() -> Dict[str, List[RCloneService]]:
    """Desteklenen tüm rclone servislerini tanımla"""
    services = {
        "📁 Bulut Depolama": [
            RCloneService("googledrive", "Google Drive", "cloud", True, True, 
                        notes="En popüler bulut depolama servisi"),
            RCloneService("onedrive", "Microsoft OneDrive", "cloud",
                        notes="Personal ve Business hesap desteği"),
            RCloneService("dropbox", "Dropbox", "cloud", True, True,
                        notes="Kolay kullanım, hızlı senkronizasyon"),
            RCloneService("box", "Box", "cloud", True, True,
                        notes="İş odaklı depolama çözümü"),
            RCloneService("mega", "MEGA", "cloud",
                        notes="Şifreli depolama, yüksek güvenlik"),
            RCloneService("pcloud", "pCloud", "cloud",
                        notes="Avrupa merkezli, GDPR uyumlu"),
            RCloneService("koofr", "Koofr", "cloud",
                        notes="Slovenya merkezli, gizlilik odaklı"),
            RCloneService("yandex", "Yandex Disk", "cloud",
                        notes="Rusya merkezli, büyük depolama"),
        ],
        
        "☁️ Kurumsal Bulut": [
            RCloneService("s3", "Amazon S3", "enterprise",
                        notes="AWS object storage"),
            RCloneService("azureblob", "Azure Blob Storage", "enterprise",
                        notes="Microsoft Azure depolama"),
            RCloneService("googlecloudstorage", "Google Cloud Storage", "enterprise", True, True,
                        notes="Google Cloud Platform"),
            RCloneService("b2", "Backblaze B2", "enterprise",
                        notes="Uygun fiyatlı object storage"),
            RCloneService("wasabi", "Wasabi", "enterprise",
                        notes="S3 uyumlu, hızlı depolama"),
        ],
        
        "🌐 FTP/SFTP": [
            RCloneService("ftp", "FTP", "protocol",
                        notes="Klasik dosya transfer protokolü"),
            RCloneService("sftp", "SFTP/SSH", "protocol",
                        notes="Güvenli dosya transfer"),
            RCloneService("webdav", "WebDAV", "protocol",
                        notes="Web tabanlı dosya erişimi"),
        ],
        
        "💾 Yerel/Ağ": [
            RCloneService("local", "Yerel Klasör", "local",
                        notes="Bilgisayarınızdaki klasörler"),
            RCloneService("smb", "SMB/CIFS", "network",
                        notes="Windows ağ paylaşımları"),
        ],
    }
    return services