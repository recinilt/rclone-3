"""
Ana uygulama sınıfı - Dual Pane RClone Manager
Geliştirilmiş bağlantı oluşturma desteği ile - PyInstaller uyumlu
"""

import os
import sys
import threading
import subprocess
from datetime import datetime
from pathlib import Path
import tkinter as tk
from tkinter import ttk, messagebox
from typing import List

# PyInstaller uyumlu absolute import'lar
from app.models import FileItem, TransferResult, initialize_services
from app.rclone_service import RCloneManager
from app.ui_components import UIComponents
from app.transfer_operations import TransferOperations
from app.dialogs import Dialogs


class DualPaneRCloneManager:
    """Ana uygulama sınıfı"""
    
    def __init__(self):
        # Ana pencere
        self.window = tk.Tk()
        self.window.title("Dual Pane RClone File Manager v1.4")
        self.window.geometry("1400x900")
        self.window.resizable(True, True)
        
        # Servisler
        self.rclone_manager = RCloneManager()
        self.ui = UIComponents(self.window)
        self.transfer_ops = TransferOperations(self.rclone_manager, self.log)
        
        # Değişkenler
        self.left_remote = None
        self.right_remote = None
        self.left_current_path = "/"
        self.right_current_path = "/"
        self.left_files = []
        self.right_files = []
        
        # Kontrol değişkenleri
        self.test_mode = tk.BooleanVar(value=False)
        self.ignore_existing = tk.BooleanVar(value=True)  # Varsayılan açık
        self.ignore_errors = tk.BooleanVar(value=True)    # Varsayılan açık
        
        # Transfer sonuçları
        self.last_transfer_result = None
        
        # Desteklenen servisler
        self.services = initialize_services()
        
        # UI öğeleri
        self.left_remote_var = tk.StringVar()
        self.right_remote_var = tk.StringVar()
        self.left_path_var = tk.StringVar(value="/")
        self.right_path_var = tk.StringVar(value="/")
        self.log_visible = False
        
        # UI oluştur
        self.setup_ui()
        self.check_rclone()
        
        # Pencere kapatma olayını yakala
        self.window.protocol("WM_DELETE_WINDOW", self._on_closing)
        
    def setup_ui(self):
        """Ana kullanıcı arayüzünü oluştur"""
        # Callback'leri hazırla
        callbacks = self._create_callbacks()
        control_vars = {
            'test_mode': self.test_mode,
            'ignore_existing': self.ignore_existing,
            'ignore_errors': self.ignore_errors
        }
        
        # Ana menü
        self.ui.setup_menu(callbacks)
        
        # Toolbar
        self.stop_btn = self.ui.setup_toolbar(callbacks, control_vars)
        
        # Ana panel (sol/sağ)
        self.setup_main_panels()
        
        # Alt durum çubuğu
        self.progress, self.status_label = self.ui.setup_status_bar(self.window)
        
        # Log penceresi
        self.log_frame, self.log_text = self.ui.setup_log_panel(self.window)
        
    def _create_callbacks(self):
        """UI callback'lerini oluştur"""
        return {
            'new_connection': self.new_connection,
            'refresh_left': self.refresh_left,
            'refresh_right': self.refresh_right,
            'quit': self._safe_quit,
            'copy_left_to_right': self.copy_left_to_right,
            'copy_right_to_left': self.copy_right_to_left,
            'bidirectional_sync': self.bidirectional_sync,
            'sync_left_to_right': self.sync_left_to_right,
            'sync_right_to_left': self.sync_right_to_left,
            'delete_selected': self.delete_selected,
            'show_last_report': self.show_last_report,
            'open_rclone_config': self.open_rclone_config,
            'list_remotes': self.list_remotes,
            'show_preferences': Dialogs.show_preferences,
            'show_help': lambda: Dialogs.show_help(self.window),
            'show_about': Dialogs.show_about,
            'toggle_log': self.toggle_log,
            'stop_operation': self.stop_operation,
            'on_test_mode_change': self.on_test_mode_change,
            'on_ignore_existing_change': self.on_ignore_existing_change,
            'on_ignore_errors_change': self.on_ignore_errors_change
        }
        
    def setup_main_panels(self):
        """Ana çift panel arayüzünü oluştur"""
        # Ana çerçeve
        main_frame = ttk.Frame(self.window)
        main_frame.pack(fill='both', expand=True, padx=5, pady=2)
        
        # Sol panel
        (self.left_frame, self.left_remote_combo, self.left_path_entry, 
         self.left_refresh_btn, self.left_tree) = self.ui.create_file_panel(
            main_frame, "📤 Sol Panel (Kaynak)", self.left_remote_var, 
            self.left_path_var, self._create_callbacks())
        self.left_frame.pack(side=tk.LEFT, fill='both', expand=True)
        
        # Event bindings - Sol panel
        self.left_remote_combo.bind('<<ComboboxSelected>>', self.on_left_remote_change)
        self.left_path_entry.bind('<Return>', self.on_left_path_change)
        self.left_refresh_btn.config(command=self.refresh_left)
        self.left_tree.bind('<Double-1>', self.on_left_double_click)
        self.left_tree.bind('<Button-3>', self.on_left_right_click)
        
        # Ayırıcı
        separator = ttk.Separator(main_frame, orient='vertical')
        separator.pack(side=tk.LEFT, fill=tk.Y, padx=5)
        
        # Sağ panel
        (self.right_frame, self.right_remote_combo, self.right_path_entry,
         self.right_refresh_btn, self.right_tree) = self.ui.create_file_panel(
            main_frame, "📥 Sağ Panel (Hedef)", self.right_remote_var,
            self.right_path_var, self._create_callbacks())
        self.right_frame.pack(side=tk.RIGHT, fill='both', expand=True)
        
        # Event bindings - Sağ panel
        self.right_remote_combo.bind('<<ComboboxSelected>>', self.on_right_remote_change)
        self.right_path_entry.bind('<Return>', self.on_right_path_change)
        self.right_refresh_btn.config(command=self.refresh_right)
        self.right_tree.bind('<Double-1>', self.on_right_double_click)
        self.right_tree.bind('<Button-3>', self.on_right_right_click)
        
    def check_rclone(self):
        """RClone kurulu mu kontrol et"""
        success, message = self.rclone_manager.check_rclone()
        if success:
            self.log(f"✅ {message}")
            self.load_remotes()
        else:
            Dialogs.show_rclone_install_dialog()
            self.rclone_manager.show_rclone_install_dialog()
            
    def load_remotes(self):
        """Mevcut remote'ları yükle"""
        remotes = self.rclone_manager.load_remotes()
        if remotes:
            self.left_remote_combo['values'] = remotes
            self.right_remote_combo['values'] = remotes
            self.log(f"📋 {len(remotes)} bağlantı yüklendi")
        else:
            self.log("⚠️ Henüz yapılandırılmış bağlantı yok")
            
    def log(self, message: str):
        """Log mesajı ekle"""
        try:
            timestamp = datetime.now().strftime("%H:%M:%S")
            self.log_text.insert(tk.END, f"[{timestamp}] {message}\n")
            self.log_text.see(tk.END)
            self.window.update()
        except:
            # Pencere kapatıldıysa konsola yaz
            print(f"[LOG] {message}")
            
    def toggle_log(self):
        """Log panelini göster/gizle"""
        if self.log_visible:
            self.log_frame.pack_forget()
            self.log_visible = False
        else:
            self.log_frame.pack(side=tk.BOTTOM, fill='both', expand=False, 
                              padx=5, pady=2)
            self.log_visible = True
            # Log açıldığında en alta scroll et
            self.log_text.see(tk.END)
            
    # Seçenek değişiklik callback'leri
    def on_test_mode_change(self):
        """Test modu değiştiğinde"""
        if self.test_mode.get():
            self.log("🧪 TEST MODU AÇIK - Dosyalar değiştirilmeyecek!")
        else:
            self.log("✅ Normal mod - Gerçek işlemler yapılacak")
            
    def on_ignore_existing_change(self):
        """Mevcut dosyaları atla seçeneği değiştiğinde"""
        if self.ignore_existing.get():
            self.log("⏭️ MEVCUT DOSYALARI ATLA AÇIK - Var olan dosyalar atlanacak")
        else:
            self.log("📝 Mevcut dosyalar üzerine yazılacak")
            
    def on_ignore_errors_change(self):
        """Hata olduğunda devam et seçeneği değiştiğinde"""
        if self.ignore_errors.get():
            self.log("🔄 HATA OLDUĞUNDA DEVAM ET AÇIK - Hatalar atlanacak")
        else:
            self.log("🛑 Hata olduğunda işlem duracak")
            
    # Remote ve path değişiklik olayları
    def on_left_remote_change(self, event=None):
        """Sol panel remote değişti"""
        self.left_remote = self.left_remote_var.get()
        self.left_current_path = "/"
        self.left_path_var.set("/")
        self.refresh_left()
        
    def on_right_remote_change(self, event=None):
        """Sağ panel remote değişti"""
        self.right_remote = self.right_remote_var.get()
        self.right_current_path = "/"
        self.right_path_var.set("/")
        self.refresh_right()
        
    def on_left_path_change(self, event=None):
        """Sol panel yolu değişti"""
        self.left_current_path = self.left_path_var.get()
        self.refresh_left()
        
    def on_right_path_change(self, event=None):
        """Sağ panel yolu değişti"""
        self.right_current_path = self.right_path_var.get()
        self.refresh_right()
        
    # Panel yenileme işlemleri
    def refresh_left(self):
        """Sol paneli yenile"""
        if not self.left_remote:
            return
            
        self.status_label.config(text="Sol panel yenileniyor...")
        threading.Thread(target=self._refresh_left_worker, daemon=False).start()
        
    def _refresh_left_worker(self):
        """Sol panel yenileme worker"""
        try:
            files = self.rclone_manager.list_files(self.left_remote, self.left_current_path)
            self.window.after(0, self._update_left_tree, files)
        except Exception as e:
            self.window.after(0, self.log, f"❌ Sol panel hatası: {e}")
        finally:
            self.window.after(0, lambda: self.status_label.config(text="Hazır"))
            
    def refresh_right(self):
        """Sağ paneli yenile"""
        if not self.right_remote:
            return
            
        self.status_label.config(text="Sağ panel yenileniyor...")
        threading.Thread(target=self._refresh_right_worker, daemon=False).start()
        
    def _refresh_right_worker(self):
        """Sağ panel yenileme worker"""
        try:
            files = self.rclone_manager.list_files(self.right_remote, self.right_current_path)
            self.window.after(0, self._update_right_tree, files)
        except Exception as e:
            self.window.after(0, self.log, f"❌ Sağ panel hatası: {e}")
        finally:
            self.window.after(0, lambda: self.status_label.config(text="Hazır"))
            
    def _update_left_tree(self, files: List[FileItem]):
        """Sol tree'yi güncelle"""
        self.left_files = files
        
        # Tree'yi temizle
        for item in self.left_tree.get_children():
            self.left_tree.delete(item)
            
        # Dosyaları ekle
        for file_item in files:
            icon = "📁" if file_item.is_dir else "📄"
            name = f"{icon} {file_item.name}"
            
            size_str = "" if file_item.is_dir else self.rclone_manager.format_size(file_item.size)
            
            self.left_tree.insert('', 'end', text=name, 
                                values=(size_str, file_item.modified))
                                
    def _update_right_tree(self, files: List[FileItem]):
        """Sağ tree'yi güncelle"""
        self.right_files = files
        
        # Tree'yi temizle
        for item in self.right_tree.get_children():
            self.right_tree.delete(item)
            
        # Dosyaları ekle
        for file_item in files:
            icon = "📁" if file_item.is_dir else "📄"
            name = f"{icon} {file_item.name}"
            
            size_str = "" if file_item.is_dir else self.rclone_manager.format_size(file_item.size)
            
            self.right_tree.insert('', 'end', text=name, 
                                 values=(size_str, file_item.modified))
                                 
    # Fare tıklama olayları
    def on_left_double_click(self, event):
        """Sol panel çift tıklama"""
        selection = self.left_tree.selection()
        if selection:
            item_id = selection[0]
            index = self.left_tree.index(item_id)
            if index < len(self.left_files):
                file_item = self.left_files[index]
                if file_item.is_dir:
                    self.left_current_path = file_item.path
                    self.left_path_var.set(file_item.path)
                    self.refresh_left()
                    
    def on_right_double_click(self, event):
        """Sağ panel çift tıklama"""
        selection = self.right_tree.selection()
        if selection:
            item_id = selection[0]
            index = self.right_tree.index(item_id)
            if index < len(self.right_files):
                file_item = self.right_files[index]
                if file_item.is_dir:
                    self.right_current_path = file_item.path
                    self.right_path_var.set(file_item.path)
                    self.refresh_right()
                    
    def on_left_right_click(self, event):
        """Sol panel sağ tıklama"""
        context_menu = tk.Menu(self.window, tearoff=0)
        context_menu.add_command(label="Sağa Kopyala", command=self.copy_left_to_right)
        context_menu.add_command(label="Sil", command=self.delete_selected)
        context_menu.add_separator()
        context_menu.add_command(label="Yenile", command=self.refresh_left)
        
        context_menu.tk_popup(event.x_root, event.y_root)
        
    def on_right_right_click(self, event):
        """Sağ panel sağ tıklama"""
        context_menu = tk.Menu(self.window, tearoff=0)
        context_menu.add_command(label="Sola Kopyala", command=self.copy_right_to_left)
        context_menu.add_command(label="Sil", command=self.delete_selected)
        context_menu.add_separator()
        context_menu.add_command(label="Yenile", command=self.refresh_right)
        
        context_menu.tk_popup(event.x_root, event.y_root)
        
    # Dosya seçimi yardımcı metodları
    def get_selected_left_files(self) -> List[FileItem]:
        """Sol panelde seçili dosyaları al"""
        selected = []
        for item_id in self.left_tree.selection():
            index = self.left_tree.index(item_id)
            if index < len(self.left_files):
                file_item = self.left_files[index]
                if file_item.name != "..":  # Üst dizini dahil etme
                    selected.append(file_item)
        return selected
        
    def get_selected_right_files(self) -> List[FileItem]:
        """Sağ panelde seçili dosyaları al"""
        selected = []
        for item_id in self.right_tree.selection():
            index = self.right_tree.index(item_id)
            if index < len(self.right_files):
                file_item = self.right_files[index]
                if file_item.name != "..":  # Üst dizini dahil etme
                    selected.append(file_item)
        return selected
        
    # Transfer işlemleri
    def copy_left_to_right(self):
        """Soldan sağa kopyala"""
        if not self.left_remote or not self.right_remote:
            Dialogs.show_no_connection_error()
            return
            
        selected = self.get_selected_left_files()
        if not selected:
            Dialogs.show_no_selection_warning()
            return
            
        self.perform_copy_operation(selected, self.left_remote, self.right_remote, 
                                  self.right_current_path)
                                  
    def copy_right_to_left(self):
        """Sağdan sola kopyala"""
        if not self.left_remote or not self.right_remote:
            Dialogs.show_no_connection_error()
            return
            
        selected = self.get_selected_right_files()
        if not selected:
            Dialogs.show_no_selection_warning()
            return
            
        self.perform_copy_operation(selected, self.right_remote, self.left_remote, 
                                  self.left_current_path)
                                  
    def perform_copy_operation(self, files: List[FileItem], source_remote: str, 
                             dest_remote: str, dest_path: str):
        """Kopyalama işlemini gerçekleştir"""
        if self.transfer_ops.running:
            Dialogs.show_operation_running_warning()
            return
            
        # Onay al
        file_names = [f.name for f in files]
        operation_type = "TEST" if self.test_mode.get() else "KOPYALAMA"
        
        if not Dialogs.show_copy_confirmation(
            file_names, operation_type, source_remote, f"{dest_remote}{dest_path}",
            self.test_mode.get(), self.ignore_existing.get(), self.ignore_errors.get()):
            return
            
        # UI durumunu güncelle
        self.stop_btn.config(state='normal')
        self.progress.start()
        
        status_text = "Test başlatılıyor..." if self.test_mode.get() else "Kopyalama başlatılıyor..."
        self.status_label.config(text=status_text)
        
        # Transfer başlat
        success = self.transfer_ops.copy_files(
            files, source_remote, dest_remote, dest_path,
            self.test_mode.get(), self.ignore_existing.get(), self.ignore_errors.get(),
            self._copy_completed
        )
        
        if not success:
            self._reset_ui()
            
    def _copy_completed(self, result: TransferResult, is_test: bool):
        """Kopyalama tamamlandı callback"""
        self.last_transfer_result = result
        
        success_count = len(result.success_files)
        failed_count = len(result.failed_files)
        skipped_count = len(result.skipped_files)
        total_count = success_count + failed_count
        
        # UI'yi ana thread'de güncelle
        self.window.after(0, self._reset_ui)
        self.window.after(0, lambda: Dialogs.show_copy_result(
            success_count, total_count, is_test, skipped_count, failed_count
        ))
        
        # Panelleri yenile (sadece gerçek kopyalamada)
        if not is_test:
            self.window.after(0, self.refresh_left)
            self.window.after(0, self.refresh_right)
            
    # Senkronizasyon işlemleri
    def bidirectional_sync(self):
        """İki yönlü senkronizasyon"""
        if not self.left_remote or not self.right_remote:
            Dialogs.show_no_connection_error()
            return
            
        if not Dialogs.show_sync_confirmation(
            "İki yönlü", self.test_mode.get(), self.ignore_errors.get(), True):
            return
            
        self._start_bidirectional_sync()
        
    def _start_bidirectional_sync(self):
        """İki yönlü senkronizasyon başlat"""
        if self.transfer_ops.running:
            Dialogs.show_operation_running_warning()
            return
            
        self.stop_btn.config(state='normal')
        self.progress.start()
        
        status_text = "Test başlatılıyor..." if self.test_mode.get() else "İki yönlü senkronizasyon..."
        self.status_label.config(text=status_text)
        
        # İlk olarak sol → sağ
        threading.Thread(target=self._bidirectional_sync_worker, daemon=False).start()
        
    def _bidirectional_sync_worker(self):
        """İki yönlü senkronizasyon worker"""
        try:
            is_test = self.test_mode.get()
            ignore_errors = self.ignore_errors.get()
            
            self.last_transfer_result = TransferResult()
            
            # Sol → Sağ
            self.log("📤 Sol → Sağ senkronizasyon...")
            
            # İlk senkronizasyonu bekle
            result1 = TransferResult()
            success1 = self._perform_single_sync(
                self.left_remote, self.left_current_path,
                self.right_remote, self.right_current_path,
                "Sol → Sağ", result1
            )
            
            if not self.transfer_ops.running:
                return
                
            # Sağ → Sol  
            self.log("📤 Sağ → Sol senkronizasyon...")
            
            result2 = TransferResult()
            success2 = self._perform_single_sync(
                self.right_remote, self.right_current_path,
                self.left_remote, self.left_current_path,
                "Sağ → Sol", result2
            )
            
            # Sonuçları birleştir
            self.last_transfer_result.success_files.extend(result1.success_files)
            self.last_transfer_result.success_files.extend(result2.success_files)
            self.last_transfer_result.failed_files.extend(result1.failed_files)
            self.last_transfer_result.failed_files.extend(result2.failed_files)
            self.last_transfer_result.error_details.update(result1.error_details)
            self.last_transfer_result.error_details.update(result2.error_details)
            
            # Sonucu göster
            overall_success = success1 and success2
            failed_count = len(self.last_transfer_result.failed_files)
            
            self.window.after(0, self._reset_ui)
            self.window.after(0, lambda: Dialogs.show_sync_result(
                overall_success, is_test, "İki yönlü", failed_count
            ))
            
            if not is_test:
                self.window.after(0, self.refresh_left)
                self.window.after(0, self.refresh_right)
                
        except Exception as e:
            self.log(f"💥 İki yönlü senkronizasyon hatası: {e}")
            self.window.after(0, self._reset_ui)
            
    def _perform_single_sync(self, source_remote: str, source_path: str,
                           dest_remote: str, dest_path: str, 
                           operation_name: str, result: TransferResult) -> bool:
        """Tek senkronizasyon işlemi gerçekleştir"""
        try:
            is_test = self.test_mode.get()
            ignore_errors = self.ignore_errors.get()
            
            source_full = f"{source_remote}{source_path}"
            dest_full = f"{dest_remote}{dest_path}"
            
            process = self.rclone_manager.create_sync_process(
                source_full, dest_full, is_test, ignore_errors
            )
            
            # Process tamamlanmasını bekle
            try:
                stdout, stderr = process.communicate(timeout=3600)  # 1 saat
                return_code = process.returncode
            except subprocess.TimeoutExpired:
                process.kill()
                return_code = -1
                stderr = "Timeout (1 saat)"
            
            # Process'i temizle
            self.rclone_manager.cleanup_process(process)
            
            if return_code == 0:
                self.log(f"✅ {operation_name} tamamlandı!")
                result.success_files.append(f"{operation_name} senkronizasyon")
                return True
            else:
                error_msg = stderr.strip() if stderr else "Bilinmeyen hata"
                self.log(f"❌ {operation_name} hatası: {error_msg[:200]}...")
                result.failed_files.append(f"{operation_name} senkronizasyon")
                result.error_details[f"{operation_name} senkronizasyon"] = [error_msg]
                return False
                
        except Exception as e:
            self.log(f"💥 {operation_name} hatası: {e}")
            result.failed_files.append(f"{operation_name} senkronizasyon")
            result.error_details[f"{operation_name} senkronizasyon"] = [str(e)]
            return False
            
    def sync_left_to_right(self):
        """Sol → Sağ senkronizasyon"""
        if not self.left_remote or not self.right_remote:
            Dialogs.show_no_connection_error()
            return
            
        if not Dialogs.show_sync_confirmation(
            "Sol → Sağ", self.test_mode.get(), self.ignore_errors.get()):
            return
            
        self._perform_sync(self.left_remote, self.left_current_path,
                         self.right_remote, self.right_current_path,
                         "Sol → Sağ")
                         
    def sync_right_to_left(self):
        """Sağ → Sol senkronizasyon"""
        if not self.left_remote or not self.right_remote:
            Dialogs.show_no_connection_error()
            return
            
        if not Dialogs.show_sync_confirmation(
            "Sağ → Sol", self.test_mode.get(), self.ignore_errors.get()):
            return
            
        self._perform_sync(self.right_remote, self.right_current_path,
                         self.left_remote, self.left_current_path,
                         "Sağ → Sol")
                         
    def _perform_sync(self, source_remote: str, source_path: str,
                     dest_remote: str, dest_path: str, operation_name: str):
        """Senkronizasyon gerçekleştir"""
        if self.transfer_ops.running:
            Dialogs.show_operation_running_warning()
            return
            
        self.stop_btn.config(state='normal')
        self.progress.start()
        
        operation_type = "test" if self.test_mode.get() else "senkronizasyon"
        status_text = f"{operation_name} {operation_type}..."
        self.status_label.config(text=status_text)
        
        success = self.transfer_ops.sync_directories(
            source_remote, source_path, dest_remote, dest_path, operation_name,
            self.test_mode.get(), self.ignore_errors.get(), self._sync_completed
        )
        
        if not success:
            self._reset_ui()
            
    def _sync_completed(self, result: TransferResult, is_test: bool, success: bool):
        """Senkronizasyon tamamlandı callback"""
        self.last_transfer_result = result
        failed_count = len(result.failed_files)
        
        # UI'yi ana thread'de güncelle
        self.window.after(0, self._reset_ui)
        self.window.after(0, lambda: Dialogs.show_sync_result(
            success, is_test, "Senkronizasyon", failed_count
        ))
        
        if not is_test:
            self.window.after(0, self.refresh_left)
            self.window.after(0, self.refresh_right)
            
    # Silme işlemleri
    def delete_selected(self):
        """Seçili öğeleri sil"""
        if self.test_mode.get():
            Dialogs.show_test_mode_warning()
            return
        
        # Hangi panelde seçim var kontrol et
        left_selected = self.get_selected_left_files()
        right_selected = self.get_selected_right_files()
        
        if left_selected:
            self._delete_files(left_selected, self.left_remote, "sol")
        elif right_selected:
            self._delete_files(right_selected, self.right_remote, "sağ")
        else:
            Dialogs.show_no_selection_warning()
            
    def _delete_files(self, files: List[FileItem], remote: str, panel_name: str):
        """Dosyaları sil"""
        file_names = [f.name for f in files]
        
        if not Dialogs.show_delete_confirmation(file_names, panel_name):
            return
            
        if self.transfer_ops.running:
            Dialogs.show_operation_running_warning()
            return
            
        self.stop_btn.config(state='normal')
        self.progress.start()
        self.status_label.config(text="Silme işlemi...")
        
        success = self.transfer_ops.delete_files(files, remote, self._delete_completed)
        
        if not success:
            self._reset_ui()
            
    def _delete_completed(self, result: TransferResult):
        """Silme tamamlandı callback"""
        self.last_transfer_result = result
        
        success_count = len(result.success_files)
        failed_count = len(result.failed_files)
        total_count = success_count + failed_count
        
        # UI'yi ana thread'de güncelle
        self.window.after(0, self._reset_ui)
        self.window.after(0, lambda: Dialogs.show_delete_result(
            success_count, total_count, failed_count
        ))
        self.window.after(0, self.refresh_left)
        self.window.after(0, self.refresh_right)
        
    # Kontrol işlemleri
    def stop_operation(self):
        """İşlemi durdur"""
        self.transfer_ops.stop_operation()
        self.log("🛑 İşlem durduruldu")
        self._reset_ui()
        
    def _reset_ui(self):
        """UI'yi sıfırla"""
        try:
            self.stop_btn.config(state='disabled')
            self.progress.stop()
            self.status_label.config(text="Hazır")
        except:
            pass
            
    # Dialog işlemleri
    def new_connection(self):
        """Yeni bağlantı dialog'u - Geliştirilmiş"""
        Dialogs.show_new_connection_dialog(self.window, self.load_remotes, self.rclone_manager)
        
    def open_rclone_config(self):
        """RClone yapılandırma dialog'u - Geliştirilmiş"""
        try:
            # Önce mevcut terminal açma yöntemini dene
            Dialogs._open_rclone_config_terminal(self.rclone_manager)
        except Exception as e:
            # Hata durumunda basit mesaj göster
            messagebox.showinfo("RClone Yapılandırması", 
                              f"Terminal açılamadı. Manuel olarak şu komutu çalıştırın:\n\n"
                              f"{self.rclone_manager.rclone_path} config\n\n"
                              f"Hata: {e}")
        
    def list_remotes(self):
        """Bağlantıları listele"""
        remotes = self.rclone_manager.load_remotes()
        Dialogs.show_remotes_list(remotes)
        
    def show_last_report(self):
        """Son işlem raporunu göster"""
        Dialogs.show_report_window(self.window, self.last_transfer_result)
        
    # Uygulama kontrol işlemleri
    def _safe_quit(self):
        """Güvenli çıkış"""
        if self.transfer_ops.running:
            if Dialogs.confirm_exit_with_operation():
                self._cleanup()
                self.window.destroy()
        else:
            self._cleanup()
            self.window.destroy()
            
    def _on_closing(self):
        """Pencere kapatılırken çağrılan fonksiyon"""
        self._safe_quit()
        
    def _cleanup(self):
        """Temizlik işlemleri"""
        try:
            # Transfer işlemlerini durdur
            self.transfer_ops.stop_operation()
            
            # RClone process'lerini sonlandır
            self.rclone_manager.terminate_all_processes()
            
            self.log("👋 Program kapatılıyor...")
        except:
            pass
            
    def run(self):
        """Uygulamayı çalıştır"""
        try:
            self.window.mainloop()
        except KeyboardInterrupt:
            self.log("👋 Program kapatılıyor...")
            self._cleanup()
            sys.exit(0)